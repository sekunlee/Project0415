﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Runtime.InteropServices;

namespace Project
{
    public partial class fMain : Form
    {
        int devCnt; // scale value 갯수
        int seq; 
        Boolean rbBool = false; // false => 수동 / true => 자동
        Boolean curState = false; // false => 응답 대기중 / true => 응답 완료
        string[] ScaleValue { get; set; }
        string[] ScaleSign { get; set; }
        string[] ScaleUnit { get; set; }
        double[] ScaleValue2 { get; set; }
        Dialog.fLog logform = null;
        arDev.RS232 dev_scale;

        string tUnit;
        ScaleCtl[] ctrls;

        Thread tRs232Con;

        int unlockCnt = 0;
        bool unlockFlg = false;

        int scaleDataCnt = 5;
        Dialog.ucSelType ucSelType;

        public fMain()
        {
            InitializeComponent();
            Pub.init();

            this.Text = Application.ProductName + " v" + Application.ProductVersion;
            this.Refresh();

            devCnt = scaleDataCnt;
            ctrls = new ScaleCtl[devCnt];
        }
        private void _Close(object sender, FormClosedEventArgs e)
        {
            /*
            dev_barcode.Close();
            dev_barcode.Dispose();
            */

            dev_scale.Close();
            dev_scale.Dispose();

            tRs232Con.Abort();
            tmDisplay.Stop();

            Pub.log.Add("프로그램 종료"); Pub.log.Flush();
        }

        private void _Load(object sender, EventArgs e)
        {
            //btPullMcName.PerformClick();

            //프로그램시작
            Pub.log.Add("프로그램 시작"); Pub.log.Flush();

            sbState.Text = "프로그램 시작";

            //초기화
            dev_scale = new arDev.RS232();
            dev_scale.BaudRate = Pub.setting.baud;
            dev_scale.DataBits = Pub.setting.dataBit;
            dev_scale.Terminal = arDev.RS232.eTerminal.CRLF;
            dev_scale.Parity = System.IO.Ports.Parity.None;
            dev_scale.StopBits = System.IO.Ports.StopBits.One;
            dev_scale.ReceiveData += Dev_Scale_ReceiveData;
            if (Pub.setting.Port.isEmpty() == false)
            {
                dev_scale.PortName = Pub.setting.Port;
                if (!dev_scale.Open()) Pub.log.AddE(dev_scale.errorMessage);
            }
            Pub.log.Add($"현재 저울 포트 = {Pub.setting.Port}");

            tUnit = Pub.setting.Xml.get_Data("scaleUnit");
            ScaleUnit = new string[devCnt];
            ScaleValue2 = new double[devCnt];
            ScaleValue = new string[devCnt];
            ScaleSign = new string[devCnt];

            //tx_recData.Text = "[AJ54700^2018-1100473^2020-1101101^^22381636^0^ASSY^231^^H/S/A^AHY290950L^^3GP^FO ZA 864^319^5061-6812]";

            Util.CheckNRegister3(Application.ProductName, "jwlee", Application.ProductVersion);

            tmDisplay.Start();

            tRs232Con = new Thread(new ThreadStart(TConProc));
            tRs232Con.Start();


            //컨트롤 생성
            genControl();
            changeBgColor();
        }

        private void TConProc()
        {
            while (true)
            {
                if (!dev_scale.IsOpen) dev_scale.Open();
                Thread.Sleep(1000);
            }
        }

        private void genControl()
        {
            devCnt = scaleDataCnt;
            ctrls = new ScaleCtl[devCnt];

            ScaleValue = new string[devCnt];
            ScaleSign = new string[devCnt];

            tableLayoutPanel1.Controls.Clear();

            for(int i = 0; i < devCnt; i++)
            {
                ScaleValue[i] = "0";
                ScaleSign[i] = "+";
            }

            //control add
            for (int i = 0; i < devCnt; i++)
            {

                var ctl = new ScaleCtl();

                ctl.MouseClick += (s1, e1) =>
                {
                    MessageBox.Show(unlockCnt.ToString());
                };

                ctl.lbSign.Text = "+";
                ctl.TitleTextEdit = "Val" + (i + 1);
                ctl.UnitTextEdit = Pub.setting.scaleUnit;

                //ctl.btGet.Text = "GET DATA";
                ctl.Dock = DockStyle.Fill;
                ctl.BtnTagEdit = i;
                ctl.Tag = i;

                // 초기화 시 부호 표시 숨김
                ctl.lbSign.Visible = false;

                if(i == 0)
                {
                    ctl.lbTitle.Click += (s1, e1) =>
                    {
                        if (unlockCnt < 5)
                        {
                            unlockCnt += 1;
                        }
                        else
                        {
                            // open input password form
                        }

                        if(unlockCnt == 5)
                        {
                            var fPw = new Dialog.Numpad();
                            fPw.ShowDialog();

                            if(fPw.DialogResult == DialogResult.OK)
                            {
                                if (Pub.lockPwInputData.Equals(Pub.lockPw))
                                {
                                    unlockFlg = true;
                                }
                            }
                        }
                    };
                }
                else
                {
                    ctl.lbTitle.Click += (s1, e1) =>
                    {
                        unlockCnt = 0;
                        unlockFlg = false;
                    };
                }


                ctl.btGet.Click += (s1, e1) =>
                {
                    var bt = s1 as Button;
                    seq = int.Parse(bt.Tag.ToString());
                    curState = false;
                    Pub.log.Add($"lbGet{ctl.BtnTagEdit}_Click() 실행"); Pub.log.Flush();
                    Pub.log.Add("Q\r\n"); Pub.log.Flush();
                    dev_scale.WriteData("Q\r\n");
                    changeBgColor();
                };

                ctl.val.Click += (s1, e1) =>
                {
                    if(unlockFlg == true)
                    {
                        valChange(Int32.Parse(ctl.Tag.ToString()));
                    }
                    
                };

                ctrls[i] = ctl;
                tableLayoutPanel1.Controls.Add(ctl);
            }

            ucSelType = new Dialog.ucSelType() { Dock = DockStyle.Fill };
            tableLayoutPanel1.Controls.Add(ucSelType);

        }


        private void btLog_Click(object sender, EventArgs e)
        {
            if (logform == null || logform.Disposing || logform.IsDisposed)
            {
                logform = new Dialog.fLog();
                logform.TopMost = true;
            }
            else
            {
                if (logform.WindowState == FormWindowState.Minimized) logform.WindowState = FormWindowState.Normal;
                if (logform.Visible == false) logform.Show();
                logform.Activate();
            }
            logform.Show();
        }

        private void btSetting_Click(object sender, EventArgs e)
        {
            var fs = new Dialog.fSetting();
            DialogResult dr = fs.ShowDialog();
            Pub.log.Add("세팅창 열기"); Pub.log.Flush();

            if (dr == DialogResult.OK)
            {
                //btPullMcName.PerformClick();

                dev_scale.Close();
                dev_scale.BaudRate = Pub.setting.baud;
                if (!dev_scale.IsOpen)
                {
                    if (Pub.setting.Port.isEmpty() == false)
                    {
                        dev_scale.PortName = Pub.setting.Port;
                        if (!dev_scale.Open()) Pub.log.AddE(dev_scale.errorMessage);
                    }
                }

                tUnit = Pub.setting.scaleUnit;
                devCnt = scaleDataCnt;

                genControl();

                seq = 0;
                changeBgColor();
            }
        }

        private void Dev_Scale_ReceiveData(object sender, arDev.RS232.ReceiveDataEventArgs e)
        {
            Pub.log.Add($"Value{seq + 1} Data 수신 시작"); 

            if (Pub.setting.scaleModel == Class.eScaleModel.AND)
            {
                string[] words = e.StrValue.Split(',');

                if (words[0].Equals("ST") || words[0].Equals("US"))
                {
                    string d = words[1];
                    char sign = '+';
                    string unit = d.Substring(9, 3).Trim();
                    d = d.Substring(1).Substring(0, 8);
                    Double val = Double.Parse(d);

                    ScaleValue[seq] = val.ToString();
                    ScaleSign[seq] = sign.ToString();
                    if (!tUnit.Equals(unit))
                    {
                        Pub.log.Add($"단위가 맞지 않습니다. 수신된 단위: {unit} / 현재 설정된 단위: {tUnit}");
                        Util.MsgE($"단위가 맞지 않습니다. 수신된 단위: {unit} / 현재 설정된 단위: {tUnit}");
                        return;
                    }


                    Pub.log.Add($"저울 수신 값 : {ScaleValue[seq]}");

                    curState = true;

                    if (true)
                    {
                        curState = false;
                        if (seq < devCnt-1) seq += 1;
                        else seq = 0;
                        changeBgColor();
                    }

                }
                else
                {
                    Pub.log.Add($"저울값 파싱 실패: {e.StrValue}");
                }
            }
            else if (Pub.setting.scaleModel == Class.eScaleModel.Quintix124)
            {
                try
                {
                    string receiveString = e.StrValue.TrimEnd('\r', '\n');
                    
                    // 데이터 길이 체크 (16문자 - \r\n 2문자 = 14문자)
                    if (receiveString.Length != 14)
                    {
                        Pub.log.AddE($"잘못된 데이터 길이: {receiveString.Length}자 (예상: 14자)");
                        return;
                    }

                    // 데이터 파싱
                    char sign = receiveString[0];                    // 부호 (1자, + 또는 -)
                    string value = receiveString.Substring(1, 9);    // 측정값 (9자)
                    string unit = receiveString.Substring(11, 3);    // 단위 (3자)

                    // 부호 검증
                    if (sign != '+' && sign != '-')
                    {
                        Pub.log.AddE($"잘못된 부호: {sign} (예상: + 또는 -)");
                        return;
                    }

                    // 측정값 파싱
                    if (double.TryParse(value, out double val))
                    {
                        // 부호 적용
                        if (sign == '-')
                            val = -val;

                        // 단위 검증
                        //if (!tUnit.Equals(unit))
                        //{
                        //    Pub.log.Add($"단위가 맞지 않습니다. 수신된 단위: {unit} / 현재 설정된 단위: {tUnit}");
                        //    Util.MsgE($"단위가 맞지 않습니다. 수신된 단위: {unit} / 현재 설정된 단위: {tUnit}");
                        //    return;
                        //}

                        // 값 저장
                        ScaleValue[seq] = Math.Abs(val).ToString();
                        ScaleSign[seq] = sign.ToString();
                        ScaleValue2[seq] = val;
                        ScaleUnit[seq] = unit;

                        Pub.log.Add($"저울 수신 값: {sign}{val} {unit}");

                        curState = true;

                        // 다음 측정으로 이동
                        if (seq < devCnt - 1)
                            seq += 1;
                        else
                            seq = 0;
                        
                        changeBgColor();
                    }
                    else
                    {
                        Pub.log.AddE($"측정값 파싱 실패: {value}");
                    }
                }
                catch (Exception ex)
                {
                    Pub.log.AddE($"데이터 처리 중 오류 발생: {ex.Message}");
                }
            }
        }

        private void tmDisplay_Tick(object sender, EventArgs e)
        {
            //lbTime.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            for (int i = 0; i < devCnt; i++)
            {
                if (Pub.setting.scaleModel == Class.eScaleModel.AND)
                {
                    ctrls[i].ValTextEdit = ScaleValue[i].ToString();
                    ctrls[i].UnitTextEdit = tUnit;
                    ctrls[i].SignTextEdit = ScaleSign[i];
                    ctrls[i].lbSign.Visible = true;
                }
                else if(Pub.setting.scaleModel == Class.eScaleModel.Quintix124)
                {
                    ctrls[i].ValTextEdit = Math.Abs(ScaleValue2[i]).ToString();
                    ctrls[i].UnitTextEdit = ScaleUnit[i] == null ? "" : ScaleUnit[i];
                    ctrls[i].SignTextEdit = ScaleSign[i];
                    
                    // 측정값이 0이 아닐 때만 부호 표시
                    ctrls[i].lbSign.Visible = (ScaleValue2[i] != 0);
                }
            }

            if (curState == true)
            {
                sbStateMsg.Text = $"Val{seq + 1} 응답완료";
            }
            else
            {
                sbStateMsg.Text = $"Val{seq + 1} 응답 대기중";
            }

            if (string.IsNullOrEmpty(Pub.setting.lineCode))
            {
                sbState.Text = "Line Code 없음";
                sbState.ForeColor = Color.Red;
            }
            else
            {
                sbState.Text = Pub.setting.lineCode;
                sbState.ForeColor = Color.Green;
            }

            if (string.IsNullOrEmpty(Pub.LOT_NO))
            {
                lbLotNo.Text = $"LOT 정보 없음";
                lbLotNo.ForeColor = Color.Red;
            }
            else
            {
                lbLotNo.Text = "LOT: " + Pub.LOT_NO;
                lbLotNo.ForeColor = Color.Green;
            }


            string sCon = $"저울 {dev_scale.PortName}: ";
            if (dev_scale.IsOpen) { sCon += "OPEN"; sbSerialState1.ForeColor = Color.Blue; }
            else { sCon += "CLOSE"; sbSerialState1.ForeColor = Color.Red; }
            sbSerialState1.Text = sCon;


            if (string.IsNullOrEmpty(Pub.LOT_NO))
            {
                btSend.Enabled = false;
            }
            else
            {
                btSend.Enabled = true;
            }
        }

        void bgColorReset()
        {
            Pub.log.Add($"bgColorReset() 실행"); Pub.log.Flush();

            for (int i = 0; i < devCnt; i++)
            {
                ctrls[i].TitleBackColor = Color.FromArgb(10, 29, 59);
            }
        }

        void changeBgColor()
        {
            bgColorReset();
            ctrls[seq].TitleBackColor = Color.FromArgb(255, 53, 53);
        }


        private void valChange(int s)
        {
            seq = s;
            curState = false;
            Pub.log.Add($"val{s} 수동입력 실행"); Pub.log.Flush();
            var fVedit = new Dialog.fEditVal(ScaleValue[s], Pub.setting.Xml.get_Data("scaleUnit"), ScaleSign[s]);
            DialogResult dr = fVedit.ShowDialog();
            if (dr == DialogResult.OK)
            {
                ScaleValue[s] = fVedit.val;
                //ScaleUnit[s] = fVedit.unit;
                ScaleSign[s] = fVedit.sign;
                Pub.log.Add($"val{s}: {ScaleSign[s]}{ScaleValue[s]}"); Pub.log.Flush();
                curState = true;
                changeBgColor();
            } 
        }

        private void btClear_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < devCnt; i++)
            {
                ScaleValue[i] = "0";
                ScaleSign[i] = "+";
                ScaleValue2[i] = 0;
                ctrls[i].ValTextEdit = "0";
                ctrls[i].SignTextEdit = "+";
                ctrls[i].lbSign.Visible = false;
            }
        }

        private void btSend_Click(object sender, EventArgs e)
        {
            string MeasurementItem = string.Empty;
            if (ucSelType.type == 1) MeasurementItem = "Adhesive";
            else if (ucSelType.type == 2) MeasurementItem = "Grease";

            try
            {
                var retval = Class.SPCAPI.Send_ProductionResult(Pub.LOT_NO);
//                MessageBox.Show(retval);
                if (retval.Substring(0, 5) == "[Fail")
                {
                    MessageBox.Show("오류: " + retval);
                    return;
                }
                //Console.WriteLine(retval);
                //Console.WriteLine("성공: " + retval);
                Pub.log.AddI("[rcvd] 1차 수신 성공: " + retval);

                var header = new Class.Header(retval);
                //Console.WriteLine("header: " + header);
                Pub.log.AddI("header: " + header);

                var sendData = new List<float>();
                for (int i = 0; i < devCnt; i++) sendData.Add(float.Parse(ScaleSign[i] + ScaleValue[i]));

                var packet = new Class.MeasurementRecord(header, MeasurementItem, tUnit, sendData);
                Pub.log.AddI("[packet] " + packet);

                String a = string.Join(", ", sendData);
                if(MessageBox.Show($"<전송될 데이터: {a} > 전송하시겠습니까? ", "SPC 전송", MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    //MessageBox.Show(packet.ToString());
                    retval = Class.SPCAPI.Send_MeasurementResult(packet.ToString());
                    Pub.log.AddI("[rcvd] " + retval);
                    MessageBox.Show("[rcvd] " + retval);
                    Pub.saveRecord(packet);
                    btClear.PerformClick();
                }                

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var fLEdit = new Dialog.fEditLot();
            fLEdit.ShowDialog();
        }
    }
}
