﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class ScaleCtl : UserControl
    {
        /// <summary>
        /// 사용자정의 컨트롤
        /// </summary>
        public ScaleCtl()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 제목의 Text를 변경합니다.
        /// </summary>
        public String TitleTextEdit
        {
            get
            {
                return lbTitle.Text;
            }
            set
            {
                lbTitle.Text = value;
                this.Invalidate();
            }
        }

        /// <summary>
        /// 제목의 배경색을 변경 합니다.
        /// </summary>
        public Color TitleBackColor
        {
            get
            {
                return lbTitle.BackColor;
            }
            set {
                lbTitle.BackColor = value;
                this.Invalidate();
            }
        }
        /// <summary>
        ///  Scale 값을 변경합니다.
        /// </summary>
        public String ValTextEdit
        { 
            get 
            {
                return val.Text;
            }
            set
            {
                val.Text = value;
                this.Invalidate();
            }
        }
        /// <summary>
        ///  단위를 변경합니다.
        /// </summary>
        public String UnitTextEdit
        {
            get
            {
                return lbUnit.Text;
            }
            set
            {
                lbUnit.Text = value;
                this.Invalidate();
            }
        }
        /// <summary>
        ///  부호를 변경합니다.
        /// </summary>
        public String SignTextEdit
        {
            get
            {
                return lbSign.Text;
            }
            set
            {
                lbSign.Text = value;
                this.Invalidate();
            }
        }
        /// <summary>
        /// btGet 버튼의 Tag값을 변경합니다.
        /// </summary>
        public Object BtnTagEdit
        {
            get
            {
                return btGet.Tag;
            }
            set
            {
                btGet.Tag = value;
                this.Invalidate();
            }
        }

        /*
        private void btGet_Click(object sender, EventArgs e)
        {
            var bt = sender as Label;
            seq = int.Parse(bt.Tag.ToString());
            curState = false;
            Pub.log.Add("lbGet1_Click() 실행"); Pub.log.Flush();
            //dev_scale.WriteData($"Q{0x0D}{0x0A}");
            changeBgColor();
        }
        */
    }
}
