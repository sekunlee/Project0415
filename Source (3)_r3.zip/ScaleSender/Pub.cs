﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    public static class Pub
    {
        public static arUtil.Log log;
        public static Class.CSetting setting;
        public static string lockPw = "0901";
        public static string lockPwInputData = string.Empty;
        public static string LOT_NO = string.Empty;
        public static string SM = string.Empty;

        public static DataTable dtRecord;

        public static void init()
        {
            log = new arUtil.Log();
            setting = new Class.CSetting();
            setting.Load();

            dtRecord = new DataTable();

            loadRecord();
        }


        static DataTable initDtLocalThick()
        {
            DataTable dt = new DataTable();
            dt.TableName = "record";

            dt.Columns.Add("scaleDevice");
            dt.Columns.Add("scaleModel");
            dt.Columns.Add("type");
            dt.Columns.Add("SM");
            dt.Columns.Add("lineCode");
            dt.Columns.Add("LotDcc");
            for (int i = 1; i <= 5; i++)
            {
                dt.Columns.Add($"value{i}", typeof(Double));
            }
            dt.Columns.Add("Date_Time", typeof(DateTime));

            return dt;
        }

        public static void loadRecord()
        {
            //xml 데이터 가져오기
            DirectoryInfo di = new DirectoryInfo("result");
            if (di.Exists)
            {
                FileInfo fi = new FileInfo($"result/{DateTime.Now.ToString("yyyy-MM-dd")}.xml");
                if (fi.Exists)
                {
                    DataSet _ds = new DataSet();
                    _ds.ReadXml(fi.FullName);
                    dtRecord = _ds.Tables[0];
                }
                else
                {
                    dtRecord = initDtLocalThick();
                }
            }
            else
            {
                dtRecord = initDtLocalThick();
            }
        }

        public static void saveRecord(Class.MeasurementRecord packet)
        {
            Pub.log.Add("Save Record");

            var nr = Pub.dtRecord.NewRow();

            nr["scaleDevice"] = Pub.setting.scaleDevice;
            nr["scaleModel"] = Pub.setting.scaleModel;
            nr["type"] = packet.type;
            nr["SM"] = Pub.SM;
            nr["lineCode"] = Pub.setting.lineCode;
            nr["LotDcc"] = Pub.LOT_NO;

            int i = 1;
            foreach (var r in packet.valList)
            {
                nr[$"value{i}"] = r;
                i++;
            }

            nr["Date_Time"] = DateTime.Now;

            Pub.dtRecord.Rows.Add(nr);

            DirectoryInfo di = new DirectoryInfo("result");
            if (di.Exists)
            {
                Pub.dtRecord.WriteXml(string.Format("result/{0}.xml", DateTime.Now.ToString("yyyy-MM-dd")));
            }
            else
            {
                di.Create();
                Pub.dtRecord.WriteXml(string.Format("result/{0}.xml", DateTime.Now.ToString("yyyy-MM-dd")));
            }
        }


    }
}
