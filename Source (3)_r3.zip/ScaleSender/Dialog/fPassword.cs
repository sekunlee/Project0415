﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project.Dialog
{
    public partial class fPassword : Form
    {
        public fPassword()
        {
            InitializeComponent();
            this.tbInput.KeyDown += (s1, e1) => { if (e1.KeyCode == Keys.Enter) Confirm(); };
            this.KeyPreview = true;
            this.KeyDown += (s1, e1) => {
                if (e1.KeyCode == Keys.Escape) this.Close();
            };
        }

        private void Confirm()
        {
            string id = tbInput.Text.Trim();
            if (id.isEmpty())
            {
                tbInput.Focus();
                return;
            }
            DialogResult = DialogResult.OK;
            Pub.lockPwInputData = id;
        }

        private void touchKey1_keyClick(string key)
        {
            if (key == "BACK" || key == "◁")
            {
                if (!tbInput.Text.isEmpty())
                {
                    if (tbInput.Text.Length == 1) tbInput.Text = "";
                    else tbInput.Text = tbInput.Text.Substring(0, tbInput.Text.Length - 1);
                }
                //if (tbInput.Text == "") tbInput.Text = "0";
            }
            else if (key == "CLEAR" || key == "RESET" || key == "◀")
            {
                tbInput.Text = "0";
            }
            else if (key == "ENTER" || key == "ENT")
            {
                Confirm();
            }
            else
            {
                if (tbInput.SelectionLength > 0 && tbInput.Text.Length == tbInput.SelectionLength)
                {
                    tbInput.Text = key;
                }
                else if (tbInput.SelectionLength > 0)
                {
                    //선택된 영역을 대체해준다.
                    tbInput.SelectedText = key;
                }
                else tbInput.Text += key;

            }

            tbInput.SelectionLength = 0;
            if (!tbInput.Text.isEmpty())
                tbInput.SelectionStart = tbInput.Text.Length;
        }

        private void touchKey1_Load(object sender, EventArgs e)
        {

        }

        private void fPassword_Load(object sender, EventArgs e)
        {

        }
    }
}
