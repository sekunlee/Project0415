﻿namespace Project.Dialog
{
    partial class fLog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panLog = new System.Windows.Forms.Panel();
            this.chkMain = new System.Windows.Forms.CheckBox();
            this.logTextBox1 = new arCtl.LogTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panLog.SuspendLayout();
            this.SuspendLayout();
            // 
            // panLog
            // 
            this.panLog.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panLog.Controls.Add(this.chkMain);
            this.panLog.Dock = System.Windows.Forms.DockStyle.Top;
            this.panLog.Location = new System.Drawing.Point(0, 0);
            this.panLog.Margin = new System.Windows.Forms.Padding(0);
            this.panLog.Name = "panLog";
            this.panLog.Padding = new System.Windows.Forms.Padding(5);
            this.panLog.Size = new System.Drawing.Size(735, 31);
            this.panLog.TabIndex = 6;
            // 
            // chkMain
            // 
            this.chkMain.Checked = true;
            this.chkMain.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkMain.Dock = System.Windows.Forms.DockStyle.Left;
            this.chkMain.Location = new System.Drawing.Point(5, 5);
            this.chkMain.Name = "chkMain";
            this.chkMain.Size = new System.Drawing.Size(70, 17);
            this.chkMain.TabIndex = 0;
            this.chkMain.Text = "Main";
            this.chkMain.UseVisualStyleBackColor = true;
            this.chkMain.Click += new System.EventHandler(this.chkMain_Click);
            // 
            // logTextBox1
            // 
            this.logTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.logTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.logTextBox1.ColorList = new arCtl.sLogMessageColor[0];
            this.logTextBox1.DateFormat = "mm:ss.fff";
            this.logTextBox1.DefaultColor = System.Drawing.Color.LightGray;
            this.logTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.logTextBox1.EnableDisplayTimer = false;
            this.logTextBox1.EnableGubunColor = true;
            this.logTextBox1.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.logTextBox1.ListFormat = "[{0}] {1}";
            this.logTextBox1.Location = new System.Drawing.Point(0, 31);
            this.logTextBox1.MaxListCount = ((ushort)(200));
            this.logTextBox1.MaxTextLength = ((uint)(4000u));
            this.logTextBox1.MessageInterval = 50;
            this.logTextBox1.Name = "logTextBox1";
            this.logTextBox1.Size = new System.Drawing.Size(735, 469);
            this.logTextBox1.TabIndex = 4;
            this.logTextBox1.Text = "";
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button1.Location = new System.Drawing.Point(0, 500);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(735, 40);
            this.button1.TabIndex = 5;
            this.button1.Text = "Load File";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // fLog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(735, 540);
            this.Controls.Add(this.logTextBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panLog);
            this.Name = "fLog";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Log Display";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.fLog_Load);
            this.panLog.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panLog;
        private arCtl.LogTextBox logTextBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox chkMain;
	}
}