﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Project;

namespace Project.Dialog
{
    public partial class fEditLot : Form
    {
        public string LOT = string.Empty;
        public string SM = string.Empty;
        public fEditLot()
        {
            InitializeComponent();
        }

        private void fEditLot_Load(object sender, EventArgs e)
        {
            this.ActiveControl = txSM;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string errMsg;

            if (string.IsNullOrEmpty(Pub.setting.lineCode)) { MessageBox.Show("Line Code를 입력하세요.", "경고"); return; }
            if (string.IsNullOrEmpty(txSM.Text)) { MessageBox.Show("SM을 입력하세요.", "경고"); return; }


            DataTable dt = Amkor.RestfulService.lot_list_by_linecode(Pub.setting.lineCode, out errMsg);

            SM = txSM.Text.ToUpper();

            Pub.log.AddI("SM 입력: " + SM);

            var qry = from order in dt.AsEnumerable()
                      where order.Field<string>("Strip_Mark").Equals(SM)
                      select new
                      {
                          lot_no = order.Field<string>("Lot_No"),
                          Strip_Mark = order.Field<string>("Strip_Mark"),
                          Current_Linecode = order.Field<string>("Current_Linecode"),
                          DCC = order.Field<string>("DCC")
                      };

            if (string.IsNullOrEmpty(qry.Select(t => t.lot_no).FirstOrDefault())) { MessageBox.Show("LOT 정보가 없습니다."); return; }
 
            String strLOTDCC = "[L" + qry.Select(t => t.lot_no).FirstOrDefault() + ", " + qry.Select(t => t.DCC).FirstOrDefault() + ",]";

            Pub.LOT_NO = strLOTDCC;
            Pub.SM = SM;

            Pub.log.AddI("LOT DCC: " + strLOTDCC + " & SM:" + SM);

            this.Close();
        }


        private void txLot_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Escape)
            {
                this.Close();
            }else if(e.KeyCode == Keys.Enter)
            {
                btnSave.PerformClick();
            }
            
        }
    }
}
