﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project.Dialog
{
    public partial class fMsgQuestion : Form
    {
        private Boolean fMove = false;
        private Point MDownPos;
        private string _msg = string.Empty;
        public Boolean DialogMode = false;

        public fMsgQuestion(string msg,string but1Text,string but2Text, string filename = "")
        {
            EnableUserClose = true;
            InitializeComponent();
            this.FormClosing += fMsgWindow_FormClosing;
            this.KeyDown += (s1, e1) => { if (EnableUserClose && e1.KeyCode == Keys.Escape) this.Close(); };
            this._msg = msg;


            if (filename != "")
            {
                string fullname = AppDomain.CurrentDomain.BaseDirectory + "Image\\" + filename;
                if (System.IO.File.Exists(fullname))
                {
                    var img = this.lb1.BackgroundImage;
                    this.lb1.BackgroundImage = Image.FromFile(fullname);
                    if (img != null) img.Dispose();
                }
                else
                {
                    msg += "\nNo Image File\n" + filename;
                }
            }
            else
            {
                var img = this.lb1.BackgroundImage;
                this.lb1.BackgroundImage = null;
                if (img != null) img.Dispose();
            }

            btYes.Text = but1Text;
            if (but2Text.isEmpty())
            {
                btNo.Visible = false;
                panSplite.Visible = false;
            }

            setMessage(msg);
            this.lbTitle.MouseMove += label1_MouseMove;
            lbTitle.MouseUp += label1_MouseUp;
            lbTitle.MouseDown += label1_MouseDown;
            lbTitle.MouseDoubleClick += label1_MouseDoubleClick;
            //btClose.Click += arLabel1_Click;
        }

        void fMsgWindow_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (DialogMode == false)
            {
                e.Cancel = true;
                return;
            }
        }

        private void fMsg_Load(object sender, EventArgs e)
        {

        }


        /// <summary>
        /// 사용자가 이 창을 닫을수 있는가?
        /// </summary>
        public Boolean EnableUserClose
        {
            get { return _enableuserclose; }
            set
            {
                _enableuserclose = value;
                // if (!EnableUserClose) btClose.Visible = false;
            }
        }
        private Boolean _enableuserclose = true;
    
        public void setMessage(string msg)
        {
            //msg를 분리해서 표시를 한다.
            var lbs = new arCtl.arLabel[] { lbTitle, lb1, lb2, lb3, lb4, lb5, lb6, lb7 };
            var lineBuf = msg.Replace("\r", "").Replace("\n\n", "\n").Split('\n');
            int maxLine = Math.Min(lbs.Length, lineBuf.Length);

            for (int i = 0; i < lbs.Length; i++)   //최대줄을 넘어가는건 표시불가
            {
                if (i >= lineBuf.Length)
                {
                    lbs[i].Text = string.Empty;
                }
                else
                {
                    if (i > 0) lbs[i].Text = string.Format("{1}", i, lineBuf[i]);
                    else lbs[i].Text = lineBuf[i];
                }
                
            }
        }
       
        private void label1_MouseMove(object sender, MouseEventArgs e)
        {
            if (fMove)
            {
                Point offset = new Point(e.X - MDownPos.X, e.Y - MDownPos.Y);
                this.Left += offset.X;
                this.Top += offset.Y;
                offset = new Point(0, 0);
            }
        }

        private void label1_MouseUp(object sender, MouseEventArgs e)
        {
            fMove = false;
        }

        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            MDownPos = new Point(e.X, e.Y);
            fMove = true;
        }

        private void label1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (EnableUserClose)
            {
                if (DialogMode == false) this.Visible = false;
                else this.Close();
            }
                
        }


        private void lbTitle_Click(object sender, EventArgs e)
        {
            if (EnableUserClose)
            {
                if (DialogMode == false)  this.Visible = false;
                else this.Close();
            }
        }

        private void tmBlink_Tick(object sender, EventArgs e)
        {
            var bg1 = lbTitle.BackColor;
            var bg2 = lbTitle.BackColor2;
            lbTitle.BackColor = bg2;
            lbTitle.BackColor2 = bg1;
        }

        private void btYes_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Yes;
        }

        private void btNo_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void arPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
