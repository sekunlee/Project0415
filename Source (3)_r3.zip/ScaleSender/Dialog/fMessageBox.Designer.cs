﻿namespace Project.Dialog
{
    partial class fMsgQuestion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tmBlink = new System.Windows.Forms.Timer(this.components);
            this.arPanel1 = new arCtl.arPanel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.btYes = new arCtl.arLabel();
            this.panSplite = new System.Windows.Forms.Panel();
            this.btNo = new arCtl.arLabel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.lb7 = new arCtl.arLabel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.lb6 = new arCtl.arLabel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lb5 = new arCtl.arLabel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lb4 = new arCtl.arLabel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lb3 = new arCtl.arLabel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lb2 = new arCtl.arLabel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lb1 = new arCtl.arLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbTitle = new arCtl.arLabel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.arPanel1.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.SuspendLayout();
            // 
            // tmBlink
            // 
            this.tmBlink.Enabled = true;
            this.tmBlink.Interval = 300;
            this.tmBlink.Tick += new System.EventHandler(this.tmBlink_Tick);
            // 
            // arPanel1
            // 
            this.arPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.arPanel1.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.arPanel1.BorderColor = System.Drawing.Color.DimGray;
            this.arPanel1.BorderSize = new System.Windows.Forms.Padding(0);
            this.arPanel1.Controls.Add(this.panel10);
            this.arPanel1.Controls.Add(this.panel8);
            this.arPanel1.Controls.Add(this.lb7);
            this.arPanel1.Controls.Add(this.panel7);
            this.arPanel1.Controls.Add(this.lb6);
            this.arPanel1.Controls.Add(this.panel6);
            this.arPanel1.Controls.Add(this.lb5);
            this.arPanel1.Controls.Add(this.panel5);
            this.arPanel1.Controls.Add(this.lb4);
            this.arPanel1.Controls.Add(this.panel4);
            this.arPanel1.Controls.Add(this.lb3);
            this.arPanel1.Controls.Add(this.panel3);
            this.arPanel1.Controls.Add(this.lb2);
            this.arPanel1.Controls.Add(this.panel2);
            this.arPanel1.Controls.Add(this.lb1);
            this.arPanel1.Controls.Add(this.panel1);
            this.arPanel1.Controls.Add(this.lbTitle);
            this.arPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.arPanel1.Font = new System.Drawing.Font("Consolas", 10F, System.Drawing.FontStyle.Italic);
            this.arPanel1.ForeColor = System.Drawing.Color.Khaki;
            this.arPanel1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.arPanel1.GradientRepeatBG = false;
            this.arPanel1.Location = new System.Drawing.Point(10, 10);
            this.arPanel1.Name = "arPanel1";
            this.arPanel1.Padding = new System.Windows.Forms.Padding(8);
            this.arPanel1.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.arPanel1.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arPanel1.ProgressMax = 100F;
            this.arPanel1.ProgressMin = 0F;
            this.arPanel1.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.arPanel1.ProgressValue = 0F;
            this.arPanel1.ShadowColor = System.Drawing.Color.Black;
            this.arPanel1.ShowBorder = true;
            this.arPanel1.Size = new System.Drawing.Size(706, 542);
            this.arPanel1.TabIndex = 4;
            this.arPanel1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.arPanel1.TextShadow = false;
            this.arPanel1.UseProgressBar = false;
            this.arPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.arPanel1_Paint);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.btYes);
            this.panel10.Controls.Add(this.panSplite);
            this.panel10.Controls.Add(this.btNo);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(8, 465);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(690, 69);
            this.panel10.TabIndex = 19;
            // 
            // btYes
            // 
            this.btYes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btYes.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btYes.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.btYes.BorderColor = System.Drawing.Color.DimGray;
            this.btYes.BorderColorOver = System.Drawing.Color.DimGray;
            this.btYes.BorderSize = new System.Windows.Forms.Padding(1);
            this.btYes.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.btYes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btYes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btYes.Font = new System.Drawing.Font("맑은 고딕", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btYes.ForeColor = System.Drawing.Color.Lime;
            this.btYes.GradientEnable = true;
            this.btYes.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.btYes.GradientRepeatBG = false;
            this.btYes.isButton = true;
            this.btYes.Location = new System.Drawing.Point(0, 0);
            this.btYes.Margin = new System.Windows.Forms.Padding(6, 3, 3, 6);
            this.btYes.MouseDownColor = System.Drawing.Color.Yellow;
            this.btYes.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btYes.msg = null;
            this.btYes.Name = "btYes";
            this.btYes.ProgressBorderColor = System.Drawing.Color.Black;
            this.btYes.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.btYes.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.btYes.ProgressEnable = false;
            this.btYes.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.btYes.ProgressForeColor = System.Drawing.Color.Black;
            this.btYes.ProgressMax = 100F;
            this.btYes.ProgressMin = 0F;
            this.btYes.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.btYes.ProgressValue = 0F;
            this.btYes.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.btYes.Sign = "";
            this.btYes.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btYes.SignColor = System.Drawing.Color.Yellow;
            this.btYes.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.btYes.Size = new System.Drawing.Size(368, 69);
            this.btYes.TabIndex = 0;
            this.btYes.Text = "YES";
            this.btYes.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btYes.TextShadow = true;
            this.btYes.TextVisible = true;
            this.btYes.Click += new System.EventHandler(this.btYes_Click);
            // 
            // panSplite
            // 
            this.panSplite.Dock = System.Windows.Forms.DockStyle.Right;
            this.panSplite.Location = new System.Drawing.Point(368, 0);
            this.panSplite.Name = "panSplite";
            this.panSplite.Size = new System.Drawing.Size(5, 69);
            this.panSplite.TabIndex = 1;
            // 
            // btNo
            // 
            this.btNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btNo.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btNo.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.btNo.BorderColor = System.Drawing.Color.DimGray;
            this.btNo.BorderColorOver = System.Drawing.Color.DimGray;
            this.btNo.BorderSize = new System.Windows.Forms.Padding(1);
            this.btNo.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.btNo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btNo.Dock = System.Windows.Forms.DockStyle.Right;
            this.btNo.Font = new System.Drawing.Font("맑은 고딕", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btNo.ForeColor = System.Drawing.Color.Tomato;
            this.btNo.GradientEnable = true;
            this.btNo.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.btNo.GradientRepeatBG = false;
            this.btNo.isButton = true;
            this.btNo.Location = new System.Drawing.Point(373, 0);
            this.btNo.Margin = new System.Windows.Forms.Padding(3, 3, 6, 6);
            this.btNo.MouseDownColor = System.Drawing.Color.Yellow;
            this.btNo.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btNo.msg = null;
            this.btNo.Name = "btNo";
            this.btNo.ProgressBorderColor = System.Drawing.Color.Black;
            this.btNo.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.btNo.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.btNo.ProgressEnable = false;
            this.btNo.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.btNo.ProgressForeColor = System.Drawing.Color.Black;
            this.btNo.ProgressMax = 100F;
            this.btNo.ProgressMin = 0F;
            this.btNo.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.btNo.ProgressValue = 0F;
            this.btNo.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.btNo.Sign = "";
            this.btNo.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btNo.SignColor = System.Drawing.Color.Yellow;
            this.btNo.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.btNo.Size = new System.Drawing.Size(317, 69);
            this.btNo.TabIndex = 0;
            this.btNo.Text = "NO";
            this.btNo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btNo.TextShadow = true;
            this.btNo.TextVisible = true;
            this.btNo.Click += new System.EventHandler(this.btNo_Click);
            // 
            // panel8
            // 
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(8, 460);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(690, 5);
            this.panel8.TabIndex = 18;
            // 
            // lb7
            // 
            this.lb7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lb7.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lb7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.lb7.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.lb7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.lb7.BorderColorOver = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.lb7.BorderSize = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.lb7.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.lb7.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lb7.Dock = System.Windows.Forms.DockStyle.Top;
            this.lb7.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold);
            this.lb7.ForeColor = System.Drawing.Color.Orange;
            this.lb7.GradientEnable = true;
            this.lb7.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.lb7.GradientRepeatBG = false;
            this.lb7.isButton = false;
            this.lb7.Location = new System.Drawing.Point(8, 410);
            this.lb7.MouseDownColor = System.Drawing.Color.Yellow;
            this.lb7.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lb7.msg = null;
            this.lb7.Name = "lb7";
            this.lb7.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.lb7.ProgressBorderColor = System.Drawing.Color.Black;
            this.lb7.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.lb7.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.lb7.ProgressEnable = false;
            this.lb7.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.lb7.ProgressForeColor = System.Drawing.Color.Black;
            this.lb7.ProgressMax = 100F;
            this.lb7.ProgressMin = 0F;
            this.lb7.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.lb7.ProgressValue = 0F;
            this.lb7.ShadowColor = System.Drawing.Color.Black;
            this.lb7.Sign = "";
            this.lb7.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.lb7.SignColor = System.Drawing.Color.Yellow;
            this.lb7.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.lb7.Size = new System.Drawing.Size(690, 50);
            this.lb7.TabIndex = 9;
            this.lb7.Text = "*";
            this.lb7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb7.TextShadow = true;
            this.lb7.TextVisible = true;
            // 
            // panel7
            // 
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(8, 405);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(690, 5);
            this.panel7.TabIndex = 17;
            // 
            // lb6
            // 
            this.lb6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lb6.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lb6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.lb6.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.lb6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.lb6.BorderColorOver = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.lb6.BorderSize = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.lb6.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.lb6.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lb6.Dock = System.Windows.Forms.DockStyle.Top;
            this.lb6.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold);
            this.lb6.ForeColor = System.Drawing.Color.Orange;
            this.lb6.GradientEnable = true;
            this.lb6.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.lb6.GradientRepeatBG = false;
            this.lb6.isButton = false;
            this.lb6.Location = new System.Drawing.Point(8, 355);
            this.lb6.MouseDownColor = System.Drawing.Color.Yellow;
            this.lb6.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lb6.msg = null;
            this.lb6.Name = "lb6";
            this.lb6.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.lb6.ProgressBorderColor = System.Drawing.Color.Black;
            this.lb6.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.lb6.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.lb6.ProgressEnable = false;
            this.lb6.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.lb6.ProgressForeColor = System.Drawing.Color.Black;
            this.lb6.ProgressMax = 100F;
            this.lb6.ProgressMin = 0F;
            this.lb6.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.lb6.ProgressValue = 0F;
            this.lb6.ShadowColor = System.Drawing.Color.Black;
            this.lb6.Sign = "";
            this.lb6.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.lb6.SignColor = System.Drawing.Color.Yellow;
            this.lb6.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.lb6.Size = new System.Drawing.Size(690, 50);
            this.lb6.TabIndex = 8;
            this.lb6.Text = "*";
            this.lb6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb6.TextShadow = true;
            this.lb6.TextVisible = true;
            // 
            // panel6
            // 
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(8, 350);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(690, 5);
            this.panel6.TabIndex = 16;
            // 
            // lb5
            // 
            this.lb5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lb5.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lb5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.lb5.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.lb5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.lb5.BorderColorOver = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.lb5.BorderSize = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.lb5.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.lb5.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lb5.Dock = System.Windows.Forms.DockStyle.Top;
            this.lb5.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold);
            this.lb5.ForeColor = System.Drawing.Color.Orange;
            this.lb5.GradientEnable = true;
            this.lb5.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.lb5.GradientRepeatBG = false;
            this.lb5.isButton = false;
            this.lb5.Location = new System.Drawing.Point(8, 300);
            this.lb5.MouseDownColor = System.Drawing.Color.Yellow;
            this.lb5.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lb5.msg = null;
            this.lb5.Name = "lb5";
            this.lb5.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.lb5.ProgressBorderColor = System.Drawing.Color.Black;
            this.lb5.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.lb5.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.lb5.ProgressEnable = false;
            this.lb5.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.lb5.ProgressForeColor = System.Drawing.Color.Black;
            this.lb5.ProgressMax = 100F;
            this.lb5.ProgressMin = 0F;
            this.lb5.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.lb5.ProgressValue = 0F;
            this.lb5.ShadowColor = System.Drawing.Color.Black;
            this.lb5.Sign = "";
            this.lb5.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.lb5.SignColor = System.Drawing.Color.Yellow;
            this.lb5.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.lb5.Size = new System.Drawing.Size(690, 50);
            this.lb5.TabIndex = 7;
            this.lb5.Text = "*";
            this.lb5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb5.TextShadow = true;
            this.lb5.TextVisible = true;
            // 
            // panel5
            // 
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(8, 295);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(690, 5);
            this.panel5.TabIndex = 15;
            // 
            // lb4
            // 
            this.lb4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lb4.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lb4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.lb4.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.lb4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.lb4.BorderColorOver = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.lb4.BorderSize = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.lb4.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.lb4.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lb4.Dock = System.Windows.Forms.DockStyle.Top;
            this.lb4.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold);
            this.lb4.ForeColor = System.Drawing.Color.Orange;
            this.lb4.GradientEnable = true;
            this.lb4.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.lb4.GradientRepeatBG = false;
            this.lb4.isButton = false;
            this.lb4.Location = new System.Drawing.Point(8, 245);
            this.lb4.MouseDownColor = System.Drawing.Color.Yellow;
            this.lb4.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lb4.msg = null;
            this.lb4.Name = "lb4";
            this.lb4.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.lb4.ProgressBorderColor = System.Drawing.Color.Black;
            this.lb4.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.lb4.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.lb4.ProgressEnable = false;
            this.lb4.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.lb4.ProgressForeColor = System.Drawing.Color.Black;
            this.lb4.ProgressMax = 100F;
            this.lb4.ProgressMin = 0F;
            this.lb4.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.lb4.ProgressValue = 0F;
            this.lb4.ShadowColor = System.Drawing.Color.Black;
            this.lb4.Sign = "";
            this.lb4.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.lb4.SignColor = System.Drawing.Color.Yellow;
            this.lb4.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.lb4.Size = new System.Drawing.Size(690, 50);
            this.lb4.TabIndex = 6;
            this.lb4.Text = "*";
            this.lb4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb4.TextShadow = true;
            this.lb4.TextVisible = true;
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(8, 240);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(690, 5);
            this.panel4.TabIndex = 14;
            // 
            // lb3
            // 
            this.lb3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lb3.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lb3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.lb3.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.lb3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.lb3.BorderColorOver = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.lb3.BorderSize = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.lb3.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.lb3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lb3.Dock = System.Windows.Forms.DockStyle.Top;
            this.lb3.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold);
            this.lb3.ForeColor = System.Drawing.Color.Orange;
            this.lb3.GradientEnable = true;
            this.lb3.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.lb3.GradientRepeatBG = false;
            this.lb3.isButton = false;
            this.lb3.Location = new System.Drawing.Point(8, 190);
            this.lb3.MouseDownColor = System.Drawing.Color.Yellow;
            this.lb3.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lb3.msg = null;
            this.lb3.Name = "lb3";
            this.lb3.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.lb3.ProgressBorderColor = System.Drawing.Color.Black;
            this.lb3.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.lb3.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.lb3.ProgressEnable = false;
            this.lb3.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.lb3.ProgressForeColor = System.Drawing.Color.Black;
            this.lb3.ProgressMax = 100F;
            this.lb3.ProgressMin = 0F;
            this.lb3.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.lb3.ProgressValue = 0F;
            this.lb3.ShadowColor = System.Drawing.Color.Black;
            this.lb3.Sign = "";
            this.lb3.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.lb3.SignColor = System.Drawing.Color.Yellow;
            this.lb3.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.lb3.Size = new System.Drawing.Size(690, 50);
            this.lb3.TabIndex = 5;
            this.lb3.Text = "*";
            this.lb3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb3.TextShadow = true;
            this.lb3.TextVisible = true;
            // 
            // panel3
            // 
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(8, 185);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(690, 5);
            this.panel3.TabIndex = 13;
            // 
            // lb2
            // 
            this.lb2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lb2.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lb2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.lb2.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.lb2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.lb2.BorderColorOver = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.lb2.BorderSize = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.lb2.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.lb2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lb2.Dock = System.Windows.Forms.DockStyle.Top;
            this.lb2.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold);
            this.lb2.ForeColor = System.Drawing.Color.Orange;
            this.lb2.GradientEnable = true;
            this.lb2.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.lb2.GradientRepeatBG = false;
            this.lb2.isButton = false;
            this.lb2.Location = new System.Drawing.Point(8, 135);
            this.lb2.MouseDownColor = System.Drawing.Color.Yellow;
            this.lb2.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lb2.msg = null;
            this.lb2.Name = "lb2";
            this.lb2.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.lb2.ProgressBorderColor = System.Drawing.Color.Black;
            this.lb2.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.lb2.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.lb2.ProgressEnable = false;
            this.lb2.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.lb2.ProgressForeColor = System.Drawing.Color.Black;
            this.lb2.ProgressMax = 100F;
            this.lb2.ProgressMin = 0F;
            this.lb2.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.lb2.ProgressValue = 0F;
            this.lb2.ShadowColor = System.Drawing.Color.Black;
            this.lb2.Sign = "";
            this.lb2.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.lb2.SignColor = System.Drawing.Color.Yellow;
            this.lb2.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.lb2.Size = new System.Drawing.Size(690, 50);
            this.lb2.TabIndex = 4;
            this.lb2.Text = "*";
            this.lb2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb2.TextShadow = true;
            this.lb2.TextVisible = true;
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(8, 130);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(690, 5);
            this.panel2.TabIndex = 12;
            // 
            // lb1
            // 
            this.lb1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lb1.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lb1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.lb1.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.lb1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.lb1.BorderColorOver = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.lb1.BorderSize = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.lb1.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.lb1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lb1.Dock = System.Windows.Forms.DockStyle.Top;
            this.lb1.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold);
            this.lb1.ForeColor = System.Drawing.Color.Orange;
            this.lb1.GradientEnable = true;
            this.lb1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.lb1.GradientRepeatBG = false;
            this.lb1.isButton = false;
            this.lb1.Location = new System.Drawing.Point(8, 80);
            this.lb1.MouseDownColor = System.Drawing.Color.Yellow;
            this.lb1.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lb1.msg = null;
            this.lb1.Name = "lb1";
            this.lb1.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.lb1.ProgressBorderColor = System.Drawing.Color.Black;
            this.lb1.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.lb1.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.lb1.ProgressEnable = false;
            this.lb1.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.lb1.ProgressForeColor = System.Drawing.Color.Black;
            this.lb1.ProgressMax = 100F;
            this.lb1.ProgressMin = 0F;
            this.lb1.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.lb1.ProgressValue = 0F;
            this.lb1.ShadowColor = System.Drawing.Color.Black;
            this.lb1.Sign = "";
            this.lb1.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.lb1.SignColor = System.Drawing.Color.Yellow;
            this.lb1.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.lb1.Size = new System.Drawing.Size(690, 50);
            this.lb1.TabIndex = 2;
            this.lb1.Text = "*";
            this.lb1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb1.TextShadow = true;
            this.lb1.TextVisible = true;
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(8, 75);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(690, 5);
            this.panel1.TabIndex = 11;
            // 
            // lbTitle
            // 
            this.lbTitle.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.lbTitle.BackColor2 = System.Drawing.Color.DodgerBlue;
            this.lbTitle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.lbTitle.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.lbTitle.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.lbTitle.BorderColorOver = System.Drawing.Color.Gray;
            this.lbTitle.BorderSize = new System.Windows.Forms.Padding(1);
            this.lbTitle.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.lbTitle.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lbTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbTitle.Font = new System.Drawing.Font("맑은 고딕", 30F, System.Drawing.FontStyle.Bold);
            this.lbTitle.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbTitle.GradientEnable = true;
            this.lbTitle.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.lbTitle.GradientRepeatBG = false;
            this.lbTitle.isButton = false;
            this.lbTitle.Location = new System.Drawing.Point(8, 8);
            this.lbTitle.MouseDownColor = System.Drawing.Color.Yellow;
            this.lbTitle.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbTitle.msg = null;
            this.lbTitle.Name = "lbTitle";
            this.lbTitle.ProgressBorderColor = System.Drawing.Color.Black;
            this.lbTitle.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.lbTitle.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.lbTitle.ProgressEnable = false;
            this.lbTitle.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.lbTitle.ProgressForeColor = System.Drawing.Color.Black;
            this.lbTitle.ProgressMax = 100F;
            this.lbTitle.ProgressMin = 0F;
            this.lbTitle.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.lbTitle.ProgressValue = 0F;
            this.lbTitle.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.lbTitle.Sign = "";
            this.lbTitle.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.lbTitle.SignColor = System.Drawing.Color.Yellow;
            this.lbTitle.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.lbTitle.Size = new System.Drawing.Size(690, 67);
            this.lbTitle.TabIndex = 3;
            this.lbTitle.Text = "TITLE";
            this.lbTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbTitle.TextShadow = true;
            this.lbTitle.TextVisible = true;
            this.lbTitle.Click += new System.EventHandler(this.lbTitle_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Controls.Add(this.arPanel1);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(1, 1);
            this.panel9.Name = "panel9";
            this.panel9.Padding = new System.Windows.Forms.Padding(10);
            this.panel9.Size = new System.Drawing.Size(726, 562);
            this.panel9.TabIndex = 5;
            // 
            // fMsgQuestion
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(728, 564);
            this.Controls.Add(this.panel9);
            this.Font = new System.Drawing.Font("Consolas", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "fMsgQuestion";
            this.Padding = new System.Windows.Forms.Padding(1);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Message Window";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.fMsg_Load);
            this.arPanel1.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        public arCtl.arLabel lb1;
        private arCtl.arPanel arPanel1;
        public arCtl.arLabel lbTitle;
        public arCtl.arLabel lb7;
        public arCtl.arLabel lb6;
        public arCtl.arLabel lb5;
        public arCtl.arLabel lb4;
        public arCtl.arLabel lb3;
        public arCtl.arLabel lb2;
        private System.Windows.Forms.Timer tmBlink;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panSplite;
        public arCtl.arLabel btYes;
        public arCtl.arLabel btNo;
    }
}