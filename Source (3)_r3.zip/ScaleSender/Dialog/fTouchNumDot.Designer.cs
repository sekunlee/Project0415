﻿namespace Project.Dialog
{
    partial class fTouchNumDot
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.arLabel1 = new arCtl.arLabel();
            this.arLabel2 = new arCtl.arLabel();
            this.arLabel3 = new arCtl.arLabel();
            this.arLabel4 = new arCtl.arLabel();
            this.arLabel5 = new arCtl.arLabel();
            this.arLabel6 = new arCtl.arLabel();
            this.arLabel7 = new arCtl.arLabel();
            this.arLabel8 = new arCtl.arLabel();
            this.arLabel9 = new arCtl.arLabel();
            this.arLabel11 = new arCtl.arLabel();
            this.arLabel12 = new arCtl.arLabel();
            this.arLabel13 = new arCtl.arLabel();
            this.arLabel14 = new arCtl.arLabel();
            this.arLabel15 = new arCtl.arLabel();
            this.arLabel10 = new arCtl.arLabel();
            this.tbInput = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Controls.Add(this.arLabel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.arLabel2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.arLabel3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.arLabel4, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.arLabel5, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.arLabel6, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.arLabel7, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.arLabel8, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.arLabel9, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.arLabel11, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.arLabel12, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.arLabel13, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.arLabel14, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.arLabel15, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.arLabel10, 3, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(5, 50);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(324, 265);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // arLabel1
            // 
            this.arLabel1.BackColor = System.Drawing.Color.SkyBlue;
            this.arLabel1.BackColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel1.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.arLabel1.BorderColor = System.Drawing.Color.SteelBlue;
            this.arLabel1.BorderColorOver = System.Drawing.Color.Red;
            this.arLabel1.BorderSize = new System.Windows.Forms.Padding(2);
            this.arLabel1.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.arLabel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.arLabel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.arLabel1.Font = new System.Drawing.Font("Consolas", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.arLabel1.ForeColor = System.Drawing.Color.White;
            this.arLabel1.GradientEnable = false;
            this.arLabel1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.arLabel1.GradientRepeatBG = false;
            this.arLabel1.isButton = true;
            this.arLabel1.Location = new System.Drawing.Point(0, 0);
            this.arLabel1.Margin = new System.Windows.Forms.Padding(0);
            this.arLabel1.MouseDownColor = System.Drawing.Color.Yellow;
            this.arLabel1.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.arLabel1.msg = null;
            this.arLabel1.Name = "arLabel1";
            this.arLabel1.ProgressBorderColor = System.Drawing.Color.Black;
            this.arLabel1.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.arLabel1.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel1.ProgressEnable = false;
            this.arLabel1.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.arLabel1.ProgressForeColor = System.Drawing.Color.Black;
            this.arLabel1.ProgressMax = 100F;
            this.arLabel1.ProgressMin = 0F;
            this.arLabel1.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.arLabel1.ProgressValue = 0F;
            this.arLabel1.ShadowColor = System.Drawing.Color.WhiteSmoke;
            this.arLabel1.Sign = "";
            this.arLabel1.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.arLabel1.SignColor = System.Drawing.Color.Yellow;
            this.arLabel1.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.arLabel1.Size = new System.Drawing.Size(81, 66);
            this.arLabel1.TabIndex = 0;
            this.arLabel1.Tag = "1";
            this.arLabel1.Text = "1";
            this.arLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.arLabel1.TextShadow = false;
            this.arLabel1.TextVisible = true;
            this.arLabel1.Click += new System.EventHandler(this.arLabel1_Click);
            // 
            // arLabel2
            // 
            this.arLabel2.BackColor = System.Drawing.Color.SkyBlue;
            this.arLabel2.BackColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel2.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.arLabel2.BorderColor = System.Drawing.Color.SteelBlue;
            this.arLabel2.BorderColorOver = System.Drawing.Color.Red;
            this.arLabel2.BorderSize = new System.Windows.Forms.Padding(2);
            this.arLabel2.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.arLabel2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.arLabel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.arLabel2.Font = new System.Drawing.Font("Consolas", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.arLabel2.ForeColor = System.Drawing.Color.White;
            this.arLabel2.GradientEnable = false;
            this.arLabel2.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.arLabel2.GradientRepeatBG = false;
            this.arLabel2.isButton = true;
            this.arLabel2.Location = new System.Drawing.Point(81, 0);
            this.arLabel2.Margin = new System.Windows.Forms.Padding(0);
            this.arLabel2.MouseDownColor = System.Drawing.Color.Yellow;
            this.arLabel2.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.arLabel2.msg = null;
            this.arLabel2.Name = "arLabel2";
            this.arLabel2.ProgressBorderColor = System.Drawing.Color.Black;
            this.arLabel2.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.arLabel2.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel2.ProgressEnable = false;
            this.arLabel2.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.arLabel2.ProgressForeColor = System.Drawing.Color.Black;
            this.arLabel2.ProgressMax = 100F;
            this.arLabel2.ProgressMin = 0F;
            this.arLabel2.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.arLabel2.ProgressValue = 0F;
            this.arLabel2.ShadowColor = System.Drawing.Color.WhiteSmoke;
            this.arLabel2.Sign = "";
            this.arLabel2.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.arLabel2.SignColor = System.Drawing.Color.Yellow;
            this.arLabel2.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.arLabel2.Size = new System.Drawing.Size(81, 66);
            this.arLabel2.TabIndex = 0;
            this.arLabel2.Tag = "2";
            this.arLabel2.Text = "2";
            this.arLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.arLabel2.TextShadow = false;
            this.arLabel2.TextVisible = true;
            this.arLabel2.Click += new System.EventHandler(this.arLabel1_Click);
            // 
            // arLabel3
            // 
            this.arLabel3.BackColor = System.Drawing.Color.SkyBlue;
            this.arLabel3.BackColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel3.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.arLabel3.BorderColor = System.Drawing.Color.SteelBlue;
            this.arLabel3.BorderColorOver = System.Drawing.Color.Red;
            this.arLabel3.BorderSize = new System.Windows.Forms.Padding(2);
            this.arLabel3.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.arLabel3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.arLabel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.arLabel3.Font = new System.Drawing.Font("Consolas", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.arLabel3.ForeColor = System.Drawing.Color.White;
            this.arLabel3.GradientEnable = false;
            this.arLabel3.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.arLabel3.GradientRepeatBG = false;
            this.arLabel3.isButton = true;
            this.arLabel3.Location = new System.Drawing.Point(162, 0);
            this.arLabel3.Margin = new System.Windows.Forms.Padding(0);
            this.arLabel3.MouseDownColor = System.Drawing.Color.Yellow;
            this.arLabel3.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.arLabel3.msg = null;
            this.arLabel3.Name = "arLabel3";
            this.arLabel3.ProgressBorderColor = System.Drawing.Color.Black;
            this.arLabel3.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.arLabel3.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel3.ProgressEnable = false;
            this.arLabel3.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.arLabel3.ProgressForeColor = System.Drawing.Color.Black;
            this.arLabel3.ProgressMax = 100F;
            this.arLabel3.ProgressMin = 0F;
            this.arLabel3.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.arLabel3.ProgressValue = 0F;
            this.arLabel3.ShadowColor = System.Drawing.Color.WhiteSmoke;
            this.arLabel3.Sign = "";
            this.arLabel3.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.arLabel3.SignColor = System.Drawing.Color.Yellow;
            this.arLabel3.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.arLabel3.Size = new System.Drawing.Size(81, 66);
            this.arLabel3.TabIndex = 0;
            this.arLabel3.Tag = "3";
            this.arLabel3.Text = "3";
            this.arLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.arLabel3.TextShadow = false;
            this.arLabel3.TextVisible = true;
            this.arLabel3.Click += new System.EventHandler(this.arLabel1_Click);
            // 
            // arLabel4
            // 
            this.arLabel4.BackColor = System.Drawing.Color.SkyBlue;
            this.arLabel4.BackColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel4.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.arLabel4.BorderColor = System.Drawing.Color.SteelBlue;
            this.arLabel4.BorderColorOver = System.Drawing.Color.Red;
            this.arLabel4.BorderSize = new System.Windows.Forms.Padding(2);
            this.arLabel4.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.arLabel4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.arLabel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.arLabel4.Font = new System.Drawing.Font("Consolas", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.arLabel4.ForeColor = System.Drawing.Color.White;
            this.arLabel4.GradientEnable = false;
            this.arLabel4.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.arLabel4.GradientRepeatBG = false;
            this.arLabel4.isButton = true;
            this.arLabel4.Location = new System.Drawing.Point(162, 66);
            this.arLabel4.Margin = new System.Windows.Forms.Padding(0);
            this.arLabel4.MouseDownColor = System.Drawing.Color.Yellow;
            this.arLabel4.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.arLabel4.msg = null;
            this.arLabel4.Name = "arLabel4";
            this.arLabel4.ProgressBorderColor = System.Drawing.Color.Black;
            this.arLabel4.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.arLabel4.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel4.ProgressEnable = false;
            this.arLabel4.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.arLabel4.ProgressForeColor = System.Drawing.Color.Black;
            this.arLabel4.ProgressMax = 100F;
            this.arLabel4.ProgressMin = 0F;
            this.arLabel4.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.arLabel4.ProgressValue = 0F;
            this.arLabel4.ShadowColor = System.Drawing.Color.WhiteSmoke;
            this.arLabel4.Sign = "";
            this.arLabel4.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.arLabel4.SignColor = System.Drawing.Color.Yellow;
            this.arLabel4.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.arLabel4.Size = new System.Drawing.Size(81, 66);
            this.arLabel4.TabIndex = 0;
            this.arLabel4.Tag = "6";
            this.arLabel4.Text = "6";
            this.arLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.arLabel4.TextShadow = false;
            this.arLabel4.TextVisible = true;
            this.arLabel4.Click += new System.EventHandler(this.arLabel1_Click);
            // 
            // arLabel5
            // 
            this.arLabel5.BackColor = System.Drawing.Color.SkyBlue;
            this.arLabel5.BackColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel5.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.arLabel5.BorderColor = System.Drawing.Color.SteelBlue;
            this.arLabel5.BorderColorOver = System.Drawing.Color.Red;
            this.arLabel5.BorderSize = new System.Windows.Forms.Padding(2);
            this.arLabel5.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.arLabel5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.arLabel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.arLabel5.Font = new System.Drawing.Font("Consolas", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.arLabel5.ForeColor = System.Drawing.Color.White;
            this.arLabel5.GradientEnable = false;
            this.arLabel5.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.arLabel5.GradientRepeatBG = false;
            this.arLabel5.isButton = true;
            this.arLabel5.Location = new System.Drawing.Point(81, 66);
            this.arLabel5.Margin = new System.Windows.Forms.Padding(0);
            this.arLabel5.MouseDownColor = System.Drawing.Color.Yellow;
            this.arLabel5.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.arLabel5.msg = null;
            this.arLabel5.Name = "arLabel5";
            this.arLabel5.ProgressBorderColor = System.Drawing.Color.Black;
            this.arLabel5.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.arLabel5.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel5.ProgressEnable = false;
            this.arLabel5.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.arLabel5.ProgressForeColor = System.Drawing.Color.Black;
            this.arLabel5.ProgressMax = 100F;
            this.arLabel5.ProgressMin = 0F;
            this.arLabel5.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.arLabel5.ProgressValue = 0F;
            this.arLabel5.ShadowColor = System.Drawing.Color.WhiteSmoke;
            this.arLabel5.Sign = "";
            this.arLabel5.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.arLabel5.SignColor = System.Drawing.Color.Yellow;
            this.arLabel5.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.arLabel5.Size = new System.Drawing.Size(81, 66);
            this.arLabel5.TabIndex = 0;
            this.arLabel5.Tag = "5";
            this.arLabel5.Text = "5";
            this.arLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.arLabel5.TextShadow = false;
            this.arLabel5.TextVisible = true;
            this.arLabel5.Click += new System.EventHandler(this.arLabel1_Click);
            // 
            // arLabel6
            // 
            this.arLabel6.BackColor = System.Drawing.Color.SkyBlue;
            this.arLabel6.BackColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel6.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.arLabel6.BorderColor = System.Drawing.Color.SteelBlue;
            this.arLabel6.BorderColorOver = System.Drawing.Color.Red;
            this.arLabel6.BorderSize = new System.Windows.Forms.Padding(2);
            this.arLabel6.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.arLabel6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.arLabel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.arLabel6.Font = new System.Drawing.Font("Consolas", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.arLabel6.ForeColor = System.Drawing.Color.White;
            this.arLabel6.GradientEnable = false;
            this.arLabel6.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.arLabel6.GradientRepeatBG = false;
            this.arLabel6.isButton = true;
            this.arLabel6.Location = new System.Drawing.Point(0, 66);
            this.arLabel6.Margin = new System.Windows.Forms.Padding(0);
            this.arLabel6.MouseDownColor = System.Drawing.Color.Yellow;
            this.arLabel6.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.arLabel6.msg = null;
            this.arLabel6.Name = "arLabel6";
            this.arLabel6.ProgressBorderColor = System.Drawing.Color.Black;
            this.arLabel6.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.arLabel6.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel6.ProgressEnable = false;
            this.arLabel6.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.arLabel6.ProgressForeColor = System.Drawing.Color.Black;
            this.arLabel6.ProgressMax = 100F;
            this.arLabel6.ProgressMin = 0F;
            this.arLabel6.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.arLabel6.ProgressValue = 0F;
            this.arLabel6.ShadowColor = System.Drawing.Color.WhiteSmoke;
            this.arLabel6.Sign = "";
            this.arLabel6.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.arLabel6.SignColor = System.Drawing.Color.Yellow;
            this.arLabel6.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.arLabel6.Size = new System.Drawing.Size(81, 66);
            this.arLabel6.TabIndex = 0;
            this.arLabel6.Tag = "4";
            this.arLabel6.Text = "4";
            this.arLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.arLabel6.TextShadow = false;
            this.arLabel6.TextVisible = true;
            this.arLabel6.Click += new System.EventHandler(this.arLabel1_Click);
            // 
            // arLabel7
            // 
            this.arLabel7.BackColor = System.Drawing.Color.SkyBlue;
            this.arLabel7.BackColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel7.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.arLabel7.BorderColor = System.Drawing.Color.SteelBlue;
            this.arLabel7.BorderColorOver = System.Drawing.Color.Red;
            this.arLabel7.BorderSize = new System.Windows.Forms.Padding(2);
            this.arLabel7.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.arLabel7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.arLabel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.arLabel7.Font = new System.Drawing.Font("Consolas", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.arLabel7.ForeColor = System.Drawing.Color.White;
            this.arLabel7.GradientEnable = false;
            this.arLabel7.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.arLabel7.GradientRepeatBG = false;
            this.arLabel7.isButton = true;
            this.arLabel7.Location = new System.Drawing.Point(0, 132);
            this.arLabel7.Margin = new System.Windows.Forms.Padding(0);
            this.arLabel7.MouseDownColor = System.Drawing.Color.Yellow;
            this.arLabel7.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.arLabel7.msg = null;
            this.arLabel7.Name = "arLabel7";
            this.arLabel7.ProgressBorderColor = System.Drawing.Color.Black;
            this.arLabel7.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.arLabel7.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel7.ProgressEnable = false;
            this.arLabel7.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.arLabel7.ProgressForeColor = System.Drawing.Color.Black;
            this.arLabel7.ProgressMax = 100F;
            this.arLabel7.ProgressMin = 0F;
            this.arLabel7.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.arLabel7.ProgressValue = 0F;
            this.arLabel7.ShadowColor = System.Drawing.Color.WhiteSmoke;
            this.arLabel7.Sign = "";
            this.arLabel7.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.arLabel7.SignColor = System.Drawing.Color.Yellow;
            this.arLabel7.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.arLabel7.Size = new System.Drawing.Size(81, 66);
            this.arLabel7.TabIndex = 0;
            this.arLabel7.Tag = "7";
            this.arLabel7.Text = "7";
            this.arLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.arLabel7.TextShadow = false;
            this.arLabel7.TextVisible = true;
            this.arLabel7.Click += new System.EventHandler(this.arLabel1_Click);
            // 
            // arLabel8
            // 
            this.arLabel8.BackColor = System.Drawing.Color.SkyBlue;
            this.arLabel8.BackColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel8.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.arLabel8.BorderColor = System.Drawing.Color.SteelBlue;
            this.arLabel8.BorderColorOver = System.Drawing.Color.Red;
            this.arLabel8.BorderSize = new System.Windows.Forms.Padding(2);
            this.arLabel8.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.arLabel8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.arLabel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.arLabel8.Font = new System.Drawing.Font("Consolas", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.arLabel8.ForeColor = System.Drawing.Color.White;
            this.arLabel8.GradientEnable = false;
            this.arLabel8.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.arLabel8.GradientRepeatBG = false;
            this.arLabel8.isButton = true;
            this.arLabel8.Location = new System.Drawing.Point(81, 132);
            this.arLabel8.Margin = new System.Windows.Forms.Padding(0);
            this.arLabel8.MouseDownColor = System.Drawing.Color.Yellow;
            this.arLabel8.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.arLabel8.msg = null;
            this.arLabel8.Name = "arLabel8";
            this.arLabel8.ProgressBorderColor = System.Drawing.Color.Black;
            this.arLabel8.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.arLabel8.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel8.ProgressEnable = false;
            this.arLabel8.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.arLabel8.ProgressForeColor = System.Drawing.Color.Black;
            this.arLabel8.ProgressMax = 100F;
            this.arLabel8.ProgressMin = 0F;
            this.arLabel8.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.arLabel8.ProgressValue = 0F;
            this.arLabel8.ShadowColor = System.Drawing.Color.WhiteSmoke;
            this.arLabel8.Sign = "";
            this.arLabel8.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.arLabel8.SignColor = System.Drawing.Color.Yellow;
            this.arLabel8.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.arLabel8.Size = new System.Drawing.Size(81, 66);
            this.arLabel8.TabIndex = 0;
            this.arLabel8.Tag = "8";
            this.arLabel8.Text = "8";
            this.arLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.arLabel8.TextShadow = false;
            this.arLabel8.TextVisible = true;
            this.arLabel8.Click += new System.EventHandler(this.arLabel1_Click);
            // 
            // arLabel9
            // 
            this.arLabel9.BackColor = System.Drawing.Color.SkyBlue;
            this.arLabel9.BackColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel9.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.arLabel9.BorderColor = System.Drawing.Color.SteelBlue;
            this.arLabel9.BorderColorOver = System.Drawing.Color.Red;
            this.arLabel9.BorderSize = new System.Windows.Forms.Padding(2);
            this.arLabel9.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.arLabel9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.arLabel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.arLabel9.Font = new System.Drawing.Font("Consolas", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.arLabel9.ForeColor = System.Drawing.Color.White;
            this.arLabel9.GradientEnable = false;
            this.arLabel9.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.arLabel9.GradientRepeatBG = false;
            this.arLabel9.isButton = true;
            this.arLabel9.Location = new System.Drawing.Point(162, 132);
            this.arLabel9.Margin = new System.Windows.Forms.Padding(0);
            this.arLabel9.MouseDownColor = System.Drawing.Color.Yellow;
            this.arLabel9.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.arLabel9.msg = null;
            this.arLabel9.Name = "arLabel9";
            this.arLabel9.ProgressBorderColor = System.Drawing.Color.Black;
            this.arLabel9.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.arLabel9.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel9.ProgressEnable = false;
            this.arLabel9.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.arLabel9.ProgressForeColor = System.Drawing.Color.Black;
            this.arLabel9.ProgressMax = 100F;
            this.arLabel9.ProgressMin = 0F;
            this.arLabel9.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.arLabel9.ProgressValue = 0F;
            this.arLabel9.ShadowColor = System.Drawing.Color.WhiteSmoke;
            this.arLabel9.Sign = "";
            this.arLabel9.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.arLabel9.SignColor = System.Drawing.Color.Yellow;
            this.arLabel9.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.arLabel9.Size = new System.Drawing.Size(81, 66);
            this.arLabel9.TabIndex = 0;
            this.arLabel9.Tag = "9";
            this.arLabel9.Text = "9";
            this.arLabel9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.arLabel9.TextShadow = false;
            this.arLabel9.TextVisible = true;
            this.arLabel9.Click += new System.EventHandler(this.arLabel1_Click);
            // 
            // arLabel11
            // 
            this.arLabel11.BackColor = System.Drawing.Color.SkyBlue;
            this.arLabel11.BackColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel11.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.arLabel11.BorderColor = System.Drawing.Color.SteelBlue;
            this.arLabel11.BorderColorOver = System.Drawing.Color.Red;
            this.arLabel11.BorderSize = new System.Windows.Forms.Padding(2);
            this.arLabel11.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.arLabel11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.arLabel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.arLabel11.Font = new System.Drawing.Font("Consolas", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.arLabel11.ForeColor = System.Drawing.Color.White;
            this.arLabel11.GradientEnable = false;
            this.arLabel11.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.arLabel11.GradientRepeatBG = false;
            this.arLabel11.isButton = true;
            this.arLabel11.Location = new System.Drawing.Point(81, 198);
            this.arLabel11.Margin = new System.Windows.Forms.Padding(0);
            this.arLabel11.MouseDownColor = System.Drawing.Color.Yellow;
            this.arLabel11.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.arLabel11.msg = null;
            this.arLabel11.Name = "arLabel11";
            this.arLabel11.ProgressBorderColor = System.Drawing.Color.Black;
            this.arLabel11.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.arLabel11.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel11.ProgressEnable = false;
            this.arLabel11.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.arLabel11.ProgressForeColor = System.Drawing.Color.Black;
            this.arLabel11.ProgressMax = 100F;
            this.arLabel11.ProgressMin = 0F;
            this.arLabel11.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.arLabel11.ProgressValue = 0F;
            this.arLabel11.ShadowColor = System.Drawing.Color.WhiteSmoke;
            this.arLabel11.Sign = "";
            this.arLabel11.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.arLabel11.SignColor = System.Drawing.Color.Yellow;
            this.arLabel11.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.arLabel11.Size = new System.Drawing.Size(81, 67);
            this.arLabel11.TabIndex = 0;
            this.arLabel11.Tag = "0";
            this.arLabel11.Text = "0";
            this.arLabel11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.arLabel11.TextShadow = false;
            this.arLabel11.TextVisible = true;
            this.arLabel11.Click += new System.EventHandler(this.arLabel1_Click);
            // 
            // arLabel12
            // 
            this.arLabel12.BackColor = System.Drawing.Color.Gray;
            this.arLabel12.BackColor2 = System.Drawing.Color.Gold;
            this.arLabel12.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.arLabel12.BorderColor = System.Drawing.Color.SteelBlue;
            this.arLabel12.BorderColorOver = System.Drawing.Color.Red;
            this.arLabel12.BorderSize = new System.Windows.Forms.Padding(2);
            this.arLabel12.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.arLabel12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.arLabel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.arLabel12.Font = new System.Drawing.Font("Consolas", 12F);
            this.arLabel12.ForeColor = System.Drawing.Color.White;
            this.arLabel12.GradientEnable = true;
            this.arLabel12.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.arLabel12.GradientRepeatBG = false;
            this.arLabel12.isButton = true;
            this.arLabel12.Location = new System.Drawing.Point(243, 0);
            this.arLabel12.Margin = new System.Windows.Forms.Padding(0);
            this.arLabel12.MouseDownColor = System.Drawing.Color.Yellow;
            this.arLabel12.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.arLabel12.msg = null;
            this.arLabel12.Name = "arLabel12";
            this.arLabel12.ProgressBorderColor = System.Drawing.Color.Black;
            this.arLabel12.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.arLabel12.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel12.ProgressEnable = false;
            this.arLabel12.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.arLabel12.ProgressForeColor = System.Drawing.Color.Black;
            this.arLabel12.ProgressMax = 100F;
            this.arLabel12.ProgressMin = 0F;
            this.arLabel12.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.arLabel12.ProgressValue = 0F;
            this.arLabel12.ShadowColor = System.Drawing.Color.WhiteSmoke;
            this.arLabel12.Sign = "";
            this.arLabel12.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.arLabel12.SignColor = System.Drawing.Color.Yellow;
            this.arLabel12.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.arLabel12.Size = new System.Drawing.Size(81, 66);
            this.arLabel12.TabIndex = 0;
            this.arLabel12.Tag = "B";
            this.arLabel12.Text = "BACK";
            this.arLabel12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.arLabel12.TextShadow = false;
            this.arLabel12.TextVisible = true;
            this.arLabel12.Click += new System.EventHandler(this.arLabel1_Click);
            // 
            // arLabel13
            // 
            this.arLabel13.BackColor = System.Drawing.Color.SkyBlue;
            this.arLabel13.BackColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel13.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.arLabel13.BorderColor = System.Drawing.Color.SteelBlue;
            this.arLabel13.BorderColorOver = System.Drawing.Color.Red;
            this.arLabel13.BorderSize = new System.Windows.Forms.Padding(2);
            this.arLabel13.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.arLabel13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.arLabel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.arLabel13.Font = new System.Drawing.Font("Consolas", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.arLabel13.ForeColor = System.Drawing.Color.White;
            this.arLabel13.GradientEnable = false;
            this.arLabel13.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.arLabel13.GradientRepeatBG = false;
            this.arLabel13.isButton = true;
            this.arLabel13.Location = new System.Drawing.Point(162, 198);
            this.arLabel13.Margin = new System.Windows.Forms.Padding(0);
            this.arLabel13.MouseDownColor = System.Drawing.Color.Yellow;
            this.arLabel13.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.arLabel13.msg = null;
            this.arLabel13.Name = "arLabel13";
            this.arLabel13.ProgressBorderColor = System.Drawing.Color.Black;
            this.arLabel13.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.arLabel13.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel13.ProgressEnable = false;
            this.arLabel13.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.arLabel13.ProgressForeColor = System.Drawing.Color.Black;
            this.arLabel13.ProgressMax = 100F;
            this.arLabel13.ProgressMin = 0F;
            this.arLabel13.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.arLabel13.ProgressValue = 0F;
            this.arLabel13.ShadowColor = System.Drawing.Color.WhiteSmoke;
            this.arLabel13.Sign = "";
            this.arLabel13.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.arLabel13.SignColor = System.Drawing.Color.Yellow;
            this.arLabel13.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.arLabel13.Size = new System.Drawing.Size(81, 67);
            this.arLabel13.TabIndex = 0;
            this.arLabel13.Tag = ".";
            this.arLabel13.Text = ".";
            this.arLabel13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.arLabel13.TextShadow = false;
            this.arLabel13.TextVisible = true;
            this.arLabel13.Click += new System.EventHandler(this.arLabel1_Click);
            // 
            // arLabel14
            // 
            this.arLabel14.BackColor = System.Drawing.Color.SkyBlue;
            this.arLabel14.BackColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel14.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.arLabel14.BorderColor = System.Drawing.Color.SteelBlue;
            this.arLabel14.BorderColorOver = System.Drawing.Color.Red;
            this.arLabel14.BorderSize = new System.Windows.Forms.Padding(2);
            this.arLabel14.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.arLabel14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.arLabel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.arLabel14.Font = new System.Drawing.Font("Consolas", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.arLabel14.ForeColor = System.Drawing.Color.White;
            this.arLabel14.GradientEnable = false;
            this.arLabel14.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.arLabel14.GradientRepeatBG = false;
            this.arLabel14.isButton = true;
            this.arLabel14.Location = new System.Drawing.Point(0, 198);
            this.arLabel14.Margin = new System.Windows.Forms.Padding(0);
            this.arLabel14.MouseDownColor = System.Drawing.Color.Yellow;
            this.arLabel14.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.arLabel14.msg = null;
            this.arLabel14.Name = "arLabel14";
            this.arLabel14.ProgressBorderColor = System.Drawing.Color.Black;
            this.arLabel14.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.arLabel14.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel14.ProgressEnable = false;
            this.arLabel14.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.arLabel14.ProgressForeColor = System.Drawing.Color.Black;
            this.arLabel14.ProgressMax = 100F;
            this.arLabel14.ProgressMin = 0F;
            this.arLabel14.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.arLabel14.ProgressValue = 0F;
            this.arLabel14.ShadowColor = System.Drawing.Color.WhiteSmoke;
            this.arLabel14.Sign = "";
            this.arLabel14.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.arLabel14.SignColor = System.Drawing.Color.Yellow;
            this.arLabel14.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.arLabel14.Size = new System.Drawing.Size(81, 67);
            this.arLabel14.TabIndex = 0;
            this.arLabel14.Tag = "-";
            this.arLabel14.Text = "-";
            this.arLabel14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.arLabel14.TextShadow = false;
            this.arLabel14.TextVisible = true;
            this.arLabel14.Click += new System.EventHandler(this.arLabel1_Click);
            // 
            // arLabel15
            // 
            this.arLabel15.BackColor = System.Drawing.Color.Gray;
            this.arLabel15.BackColor2 = System.Drawing.Color.SteelBlue;
            this.arLabel15.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.arLabel15.BorderColor = System.Drawing.Color.SteelBlue;
            this.arLabel15.BorderColorOver = System.Drawing.Color.Red;
            this.arLabel15.BorderSize = new System.Windows.Forms.Padding(2);
            this.arLabel15.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.arLabel15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.arLabel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.arLabel15.Font = new System.Drawing.Font("Consolas", 12F);
            this.arLabel15.ForeColor = System.Drawing.Color.White;
            this.arLabel15.GradientEnable = true;
            this.arLabel15.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.arLabel15.GradientRepeatBG = false;
            this.arLabel15.isButton = true;
            this.arLabel15.Location = new System.Drawing.Point(243, 66);
            this.arLabel15.Margin = new System.Windows.Forms.Padding(0);
            this.arLabel15.MouseDownColor = System.Drawing.Color.Yellow;
            this.arLabel15.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.arLabel15.msg = null;
            this.arLabel15.Name = "arLabel15";
            this.arLabel15.ProgressBorderColor = System.Drawing.Color.Black;
            this.arLabel15.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.arLabel15.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel15.ProgressEnable = false;
            this.arLabel15.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.arLabel15.ProgressForeColor = System.Drawing.Color.Black;
            this.arLabel15.ProgressMax = 100F;
            this.arLabel15.ProgressMin = 0F;
            this.arLabel15.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.arLabel15.ProgressValue = 0F;
            this.arLabel15.ShadowColor = System.Drawing.Color.WhiteSmoke;
            this.arLabel15.Sign = "";
            this.arLabel15.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.arLabel15.SignColor = System.Drawing.Color.Yellow;
            this.arLabel15.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.arLabel15.Size = new System.Drawing.Size(81, 66);
            this.arLabel15.TabIndex = 0;
            this.arLabel15.Tag = "C";
            this.arLabel15.Text = "CLEAR";
            this.arLabel15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.arLabel15.TextShadow = false;
            this.arLabel15.TextVisible = true;
            this.arLabel15.Click += new System.EventHandler(this.arLabel1_Click);
            // 
            // arLabel10
            // 
            this.arLabel10.BackColor = System.Drawing.Color.CadetBlue;
            this.arLabel10.BackColor2 = System.Drawing.Color.Lime;
            this.arLabel10.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.arLabel10.BorderColor = System.Drawing.Color.SteelBlue;
            this.arLabel10.BorderColorOver = System.Drawing.Color.Red;
            this.arLabel10.BorderSize = new System.Windows.Forms.Padding(2);
            this.arLabel10.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.arLabel10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.arLabel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.arLabel10.Font = new System.Drawing.Font("Consolas", 12F);
            this.arLabel10.ForeColor = System.Drawing.Color.White;
            this.arLabel10.GradientEnable = true;
            this.arLabel10.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.arLabel10.GradientRepeatBG = false;
            this.arLabel10.isButton = true;
            this.arLabel10.Location = new System.Drawing.Point(243, 132);
            this.arLabel10.Margin = new System.Windows.Forms.Padding(0);
            this.arLabel10.MouseDownColor = System.Drawing.Color.Yellow;
            this.arLabel10.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.arLabel10.msg = null;
            this.arLabel10.Name = "arLabel10";
            this.arLabel10.ProgressBorderColor = System.Drawing.Color.Black;
            this.arLabel10.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.arLabel10.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.arLabel10.ProgressEnable = false;
            this.arLabel10.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.arLabel10.ProgressForeColor = System.Drawing.Color.Black;
            this.arLabel10.ProgressMax = 100F;
            this.arLabel10.ProgressMin = 0F;
            this.arLabel10.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.arLabel10.ProgressValue = 0F;
            this.tableLayoutPanel1.SetRowSpan(this.arLabel10, 2);
            this.arLabel10.ShadowColor = System.Drawing.Color.WhiteSmoke;
            this.arLabel10.Sign = "";
            this.arLabel10.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.arLabel10.SignColor = System.Drawing.Color.Yellow;
            this.arLabel10.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.arLabel10.Size = new System.Drawing.Size(81, 133);
            this.arLabel10.TabIndex = 0;
            this.arLabel10.Tag = "E";
            this.arLabel10.Text = "ENTER";
            this.arLabel10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.arLabel10.TextShadow = false;
            this.arLabel10.TextVisible = true;
            this.arLabel10.Click += new System.EventHandler(this.arLabel1_Click);
            // 
            // tbInput
            // 
            this.tbInput.Dock = System.Windows.Forms.DockStyle.Top;
            this.tbInput.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbInput.Location = new System.Drawing.Point(5, 5);
            this.tbInput.Name = "tbInput";
            this.tbInput.Size = new System.Drawing.Size(324, 40);
            this.tbInput.TabIndex = 2;
            this.tbInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(5, 45);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(324, 5);
            this.panel1.TabIndex = 3;
            // 
            // fTouchNumDot
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(334, 320);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tbInput);
            this.Name = "fTouchNumDot";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Input Value";
            this.Load += new System.EventHandler(this.fTouchNumDot_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private arCtl.arLabel arLabel1;
        private arCtl.arLabel arLabel2;
        private arCtl.arLabel arLabel3;
        private arCtl.arLabel arLabel4;
        private arCtl.arLabel arLabel5;
        private arCtl.arLabel arLabel6;
        private arCtl.arLabel arLabel7;
        private arCtl.arLabel arLabel8;
        private arCtl.arLabel arLabel9;
        private arCtl.arLabel arLabel10;
        private arCtl.arLabel arLabel11;
        private arCtl.arLabel arLabel12;
        public System.Windows.Forms.TextBox tbInput;
        private System.Windows.Forms.Panel panel1;
        private arCtl.arLabel arLabel13;
        private arCtl.arLabel arLabel14;
        private arCtl.arLabel arLabel15;
    }
}