﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project.Dialog
{
    public partial class fErrorException : Form
    {
        public fErrorException(string err)
        {
            InitializeComponent();
            System.Text.StringBuilder sb = new StringBuilder();
            sb.AppendLine("===============================");
            sb.AppendLine("개발 : ChiKyun.kim@amkor.co.kr");
            sb.AppendLine("소속 : ATK-4 EET 1P");
            sb.AppendLine("===============================");
            sb.AppendLine();
            sb.AppendLine(err);
            this.textBox1.Text = sb.ToString();

            this.lbTitle.MouseMove += LbTitle_MouseMove;
            this.lbTitle.MouseUp += LbTitle_MouseUp;
            this.lbTitle.MouseDown += LbTitle_MouseDown;
            this.lbTitle.DoubleClick += LbTitle_DoubleClick;
        }

        private void fErrorException_Load(object sender, EventArgs e)
        {

        }

        #region "Mouse Form Move"

        private Boolean fMove = false;
        private Point MDownPos;

        private void LbTitle_DoubleClick(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Maximized) this.WindowState = FormWindowState.Normal;
            else this.WindowState = FormWindowState.Maximized;
        }
        private void LbTitle_MouseMove(object sender, MouseEventArgs e)
        {
            if (fMove)
            {
                Point offset = new Point(e.X - MDownPos.X, e.Y - MDownPos.Y);
                this.Left += offset.X;
                this.Top += offset.Y;
                offset = new Point(0, 0);
            }
        }
        private void LbTitle_MouseUp(object sender, MouseEventArgs e)
        {
            fMove = false;
        }
        private void LbTitle_MouseDown(object sender, MouseEventArgs e)
        {
            MDownPos = new Point(e.X, e.Y);
            fMove = true;
        }

        #endregion

        private void btTeach_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
