﻿namespace Project.Dialog
{
    partial class fErrorException
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fErrorException));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panTitleBar = new System.Windows.Forms.Panel();
            this.lbTitle = new arCtl.arLabel();
            this.btTeach = new arCtl.arLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panTitleBar.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(234, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(80, 80);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(28, 106);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(10);
            this.label1.Size = new System.Drawing.Size(488, 50);
            this.label1.TabIndex = 3;
            this.label1.Text = "미처리 오류로 인해 프로그램이 중단 되었습니다";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label2.Location = new System.Drawing.Point(46, 159);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(386, 45);
            this.label2.TabIndex = 4;
            this.label2.Text = "오류보고를 위한 정보가 수집되었습니다.\r\n수집된 정보는 아래에 같습니다.\r\n발생전 상황을 포함하여 \"Chikyun.kim@amkor.co.kr\" " +
    "로 보내주십시요.";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.ForeColor = System.Drawing.Color.LightCoral;
            this.textBox1.Location = new System.Drawing.Point(10, 218);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(514, 346);
            this.textBox1.TabIndex = 5;
            this.textBox1.Text = "test";
            // 
            // panTitleBar
            // 
            this.panTitleBar.BackColor = System.Drawing.Color.Maroon;
            this.panTitleBar.Controls.Add(this.lbTitle);
            this.panTitleBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.panTitleBar.Location = new System.Drawing.Point(1, 1);
            this.panTitleBar.Name = "panTitleBar";
            this.panTitleBar.Size = new System.Drawing.Size(534, 32);
            this.panTitleBar.TabIndex = 133;
            // 
            // lbTitle
            // 
            this.lbTitle.BackColor = System.Drawing.Color.Transparent;
            this.lbTitle.BackColor2 = System.Drawing.Color.Transparent;
            this.lbTitle.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.lbTitle.BorderColor = System.Drawing.Color.Red;
            this.lbTitle.BorderColorOver = System.Drawing.Color.Red;
            this.lbTitle.BorderSize = new System.Windows.Forms.Padding(0);
            this.lbTitle.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.lbTitle.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lbTitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbTitle.Font = new System.Drawing.Font("Cambria", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitle.ForeColor = System.Drawing.Color.LightSkyBlue;
            this.lbTitle.GradientEnable = true;
            this.lbTitle.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.lbTitle.GradientRepeatBG = false;
            this.lbTitle.isButton = false;
            this.lbTitle.Location = new System.Drawing.Point(0, 0);
            this.lbTitle.MouseDownColor = System.Drawing.Color.Yellow;
            this.lbTitle.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbTitle.msg = null;
            this.lbTitle.Name = "lbTitle";
            this.lbTitle.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.lbTitle.ProgressBorderColor = System.Drawing.Color.Black;
            this.lbTitle.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.lbTitle.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.lbTitle.ProgressEnable = false;
            this.lbTitle.ProgressFont = new System.Drawing.Font("Consolas", 10F);
            this.lbTitle.ProgressForeColor = System.Drawing.Color.Black;
            this.lbTitle.ProgressMax = 100F;
            this.lbTitle.ProgressMin = 0F;
            this.lbTitle.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.lbTitle.ProgressValue = 0F;
            this.lbTitle.ShadowColor = System.Drawing.Color.WhiteSmoke;
            this.lbTitle.Sign = "";
            this.lbTitle.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.lbTitle.SignColor = System.Drawing.Color.Yellow;
            this.lbTitle.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.lbTitle.Size = new System.Drawing.Size(534, 32);
            this.lbTitle.TabIndex = 60;
            this.lbTitle.Text = "UnhandledException";
            this.lbTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbTitle.TextShadow = false;
            this.lbTitle.TextVisible = true;
            // 
            // btTeach
            // 
            this.btTeach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btTeach.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.btTeach.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
            this.btTeach.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.btTeach.BorderColorOver = System.Drawing.Color.DarkBlue;
            this.btTeach.BorderSize = new System.Windows.Forms.Padding(0);
            this.btTeach.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
            this.btTeach.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btTeach.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btTeach.Font = new System.Drawing.Font("맑은 고딕", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btTeach.ForeColor = System.Drawing.Color.DeepPink;
            this.btTeach.GradientEnable = false;
            this.btTeach.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.btTeach.GradientRepeatBG = false;
            this.btTeach.isButton = true;
            this.btTeach.Location = new System.Drawing.Point(1, 610);
            this.btTeach.Margin = new System.Windows.Forms.Padding(0, 0, 5, 0);
            this.btTeach.MouseDownColor = System.Drawing.Color.Yellow;
            this.btTeach.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btTeach.msg = null;
            this.btTeach.Name = "btTeach";
            this.btTeach.ProgressBorderColor = System.Drawing.Color.Black;
            this.btTeach.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
            this.btTeach.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
            this.btTeach.ProgressEnable = false;
            this.btTeach.ProgressFont = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btTeach.ProgressForeColor = System.Drawing.Color.Black;
            this.btTeach.ProgressMax = 100F;
            this.btTeach.ProgressMin = 0F;
            this.btTeach.ProgressPadding = new System.Windows.Forms.Padding(0);
            this.btTeach.ProgressValue = 0F;
            this.btTeach.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btTeach.Sign = "";
            this.btTeach.SignAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btTeach.SignColor = System.Drawing.Color.Yellow;
            this.btTeach.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
            this.btTeach.Size = new System.Drawing.Size(534, 61);
            this.btTeach.TabIndex = 134;
            this.btTeach.Text = "종 료";
            this.btTeach.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btTeach.TextShadow = true;
            this.btTeach.TextVisible = true;
            this.btTeach.Click += new System.EventHandler(this.btTeach_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(1, 33);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(534, 577);
            this.panel1.TabIndex = 135;
            // 
            // fErrorException
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.ClientSize = new System.Drawing.Size(536, 672);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btTeach);
            this.Controls.Add(this.panTitleBar);
            this.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "fErrorException";
            this.Padding = new System.Windows.Forms.Padding(1);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Error Report";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.fErrorException_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panTitleBar.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.Panel panTitleBar;
        private arCtl.arLabel lbTitle;
        private arCtl.arLabel btTeach;
        private System.Windows.Forms.Panel panel1;
    }
}