﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project.Dialog
{
    public partial class fLog : Form
    {
        public fLog()
        {
            InitializeComponent();
            Pub.log.RaiseMsg += log_RaiseMsg;
        }

		private void fLog_Load(object sender, EventArgs e)
        {
            this.logTextBox1.ColorList = new arCtl.sLogMessageColor[] {
                new arCtl.sLogMessageColor("FLAG",Color.SkyBlue),
                new arCtl.sLogMessageColor("ILOCK", Color.Gold),
                new arCtl.sLogMessageColor("ERR",Color.Red),
                new arCtl.sLogMessageColor("ATT", Color.Tomato),
                new arCtl.sLogMessageColor("NORM", Color.WhiteSmoke),
            };
			//timer1.Start();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            var od = new OpenFileDialog();
            od.InitialDirectory = Pub.log.BaseDirectory;
            if (od.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.logTextBox1.Text = System.IO.File.ReadAllText(od.FileName, System.Text.Encoding.Default);
            }
        }

        private void chkMain_Click(object sender, EventArgs e)
        {

        }
		

        void log_RaiseMsg(DateTime LogTime, string TypeStr, string Message)
        {
            if (this.chkMain.Checked) this.logTextBox1.AddMsg(LogTime, TypeStr, Message);
        }

	}
}
