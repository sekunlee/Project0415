﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project.Dialog
{
    public partial class fEditVal : Form
    {
        public string val = "0";
        public string unit = "g";
        public string sign = "+";
        public fEditVal(string v, string u, string s)
        {
            InitializeComponent();
            val = v;
            unit = u;
            sign = s;
        }
        private void fEditVal_Load(object sender, EventArgs e)
        {
            txVal.Text = val;
            //cbUnit.SelectedItem = unit;
            cbSign.SelectedItem = sign;
        }


        private void txVal_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
            else if (e.KeyCode == Keys.Enter)
            {
                btnSave.PerformClick();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            this.val = txVal.Text;
            //this.unit = cbUnit.SelectedItem.ToString();
            this.sign = cbSign.SelectedItem.ToString();
            this.DialogResult = DialogResult.OK;
            this.Dispose();
        }
    }
}
