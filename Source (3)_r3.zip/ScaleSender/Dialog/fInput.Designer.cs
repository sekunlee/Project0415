﻿namespace Project.Dialog
{
    partial class fInput
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbInput = new System.Windows.Forms.TextBox();
            this.touchKey1 = new arCtl.TouchKey();
            this.SuspendLayout();
            // 
            // tbInput
            // 
            this.tbInput.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbInput.Location = new System.Drawing.Point(26, 21);
            this.tbInput.Name = "tbInput";
            this.tbInput.Size = new System.Drawing.Size(479, 40);
            this.tbInput.TabIndex = 1;
            this.tbInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // touchKey1
            // 
            this.touchKey1.Location = new System.Drawing.Point(18, 75);
            this.touchKey1.Margin = new System.Windows.Forms.Padding(9, 21, 9, 21);
            this.touchKey1.Name = "touchKey1";
            this.touchKey1.Size = new System.Drawing.Size(503, 381);
            this.touchKey1.TabIndex = 5;
            this.touchKey1.keyClick += new arCtl.TouchKey.KeyClickHandler(this.touchKey1_keyClick);
            // 
            // fInput
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(539, 486);
            this.Controls.Add(this.touchKey1);
            this.Controls.Add(this.tbInput);
            this.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "fInput";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Input Value";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.fInput_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox tbInput;
        private arCtl.TouchKey touchKey1;
    }
}