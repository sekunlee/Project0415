﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project.Dialog
{
    public partial class fTouchKey : Form
    {
        public fTouchKey()
        {
            InitializeComponent();
        }

        private void touchKeyCalc1_Load(object sender, EventArgs e)
        {

        }
    }
}
