﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project.Dialog
{
	public partial class fTouchKeyFull : Form
	{
		public fTouchKeyFull(string title, string value)
		{
			InitializeComponent();
			this.lbTitle.Text = title;
			this.tbInput.Text = value;
			this.KeyDown += (s1, e1) =>
			{
				if (e1.KeyCode == Keys.Escape)
					this.Close();
			};
			this.lbTitle.MouseMove += LbTitle_MouseMove;
			this.lbTitle.MouseUp += LbTitle_MouseUp;
			this.lbTitle.MouseDown += LbTitle_MouseDown;
		}

		private void fTouchKeyFull_Load(object sender, EventArgs e)
		{
			this.Show();
			//'Application.DoEvents();
			this.tbInput.SelectAll();
			this.tbInput.Focus();
		}
		#region "Mouse Form Move"

		private Boolean fMove = false;
		private Point MDownPos;
		private void LbTitle_MouseMove(object sender, MouseEventArgs e)
		{
			if (fMove)
			{
				Point offset = new Point(e.X - MDownPos.X, e.Y - MDownPos.Y);
				this.Left += offset.X;
				this.Top += offset.Y;
				offset = new Point(0, 0);
			}
		}
		private void LbTitle_MouseUp(object sender, MouseEventArgs e)
		{
			fMove = false;
		}
		private void LbTitle_MouseDown(object sender, MouseEventArgs e)
		{
			MDownPos = new Point(e.X, e.Y);
			fMove = true;
		}

		#endregion

		private void touchKeyFull1_keyClick(string key)
		{
			switch (key)
			{
				case "CLR":
					this.tbInput.Text = string.Empty;
					break;
				case "BACK":

					if (this.tbInput.SelectionLength > 0)
					{
						//특정영역이 선택되었다
						var head = tbInput.Text.Substring(0, tbInput.SelectionStart);
						var tail = tbInput.Text.Substring(tbInput.SelectionLength + tbInput.SelectionStart);
						tbInput.Text = head + tail;
						tbInput.SelectionStart = head.Length;
						tbInput.SelectionLength = 0;
					}
					else
					{
						var si = this.tbInput.SelectionStart - 1;
						var sl = this.tbInput.SelectionLength;
						if(si >= 0)
						{
							var head = tbInput.Text.Substring(0, si);
							var tail = tbInput.Text.Substring(si + 1);

							tbInput.Text = head + tail;
							tbInput.SelectionStart = head.Length;
							tbInput.SelectionLength = 0;
						}
					}

					break;
				case "ENTER":
					this.DialogResult = DialogResult.OK;
					break;
				default:
					var si2 = this.tbInput.SelectionStart ;
					var head2 = tbInput.Text.Substring(0, si2);
					var tail2 = tbInput.Text.Substring(si2 );

					tbInput.Text = head2 + key + tail2;
					tbInput.SelectionStart = head2.Length+1;
					tbInput.SelectionLength = 0;


					//this.tbInput.Text += key;
					//this.tbInput.SelectionStart = this.tbInput.TextLength;

					break;
			}
			this.tbInput.Focus();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			//앞에서 삭제
			if (this.tbInput.Text.Length < 1) return;
			if (this.tbInput.Text.Length < 2) tbInput.Text = string.Empty;
			else tbInput.Text = tbInput.Text.Substring(1);
			tbInput.SelectionStart = 0;// this.tbInput.TextLength;
			tbInput.Focus();
		}

		private void button3_Click(object sender, EventArgs e)
		{
			//두에서 삭제
			if (this.tbInput.Text.Length < 1) return;
			if (this.tbInput.Text.Length < 2) tbInput.Text = string.Empty;
			else tbInput.Text = tbInput.Text.Substring(0, tbInput.Text.Length - 1);
			tbInput.SelectionStart = this.tbInput.TextLength;
			tbInput.Focus();
		}
	}
}
