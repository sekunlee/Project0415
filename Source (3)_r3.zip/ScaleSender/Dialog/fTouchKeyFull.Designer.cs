﻿namespace Project.Dialog
{
    partial class fTouchKeyFull
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.touchKeyFull1 = new arCtl.TouchKeyFull();
			this.tbInput = new System.Windows.Forms.TextBox();
			this.lbTitle = new arCtl.arLabel();
			this.button1 = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.button3 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// touchKeyFull1
			// 
			this.touchKeyFull1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.touchKeyFull1.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.touchKeyFull1.Location = new System.Drawing.Point(6, 96);
			this.touchKeyFull1.Name = "touchKeyFull1";
			this.touchKeyFull1.Size = new System.Drawing.Size(1088, 359);
			this.touchKeyFull1.TabIndex = 0;
			this.touchKeyFull1.keyClick += new arCtl.TouchKeyFull.KeyClickHandler(this.touchKeyFull1_keyClick);
			// 
			// tbInput
			// 
			this.tbInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.tbInput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tbInput.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tbInput.Font = new System.Drawing.Font("맑은 고딕", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.tbInput.ForeColor = System.Drawing.Color.White;
			this.tbInput.Location = new System.Drawing.Point(100, 0);
			this.tbInput.Name = "tbInput";
			this.tbInput.Size = new System.Drawing.Size(888, 46);
			this.tbInput.TabIndex = 0;
			this.tbInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// lbTitle
			// 
			this.lbTitle.BackColor = System.Drawing.Color.Gray;
			this.lbTitle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
			this.lbTitle.BackgroundImagePadding = new System.Windows.Forms.Padding(0);
			this.lbTitle.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
			this.lbTitle.BorderColorOver = System.Drawing.Color.DarkBlue;
			this.lbTitle.BorderSize = new System.Windows.Forms.Padding(1);
			this.lbTitle.ColorTheme = arCtl.arLabel.eColorTheme.Custom;
			this.lbTitle.Cursor = System.Windows.Forms.Cursors.Arrow;
			this.lbTitle.Dock = System.Windows.Forms.DockStyle.Top;
			this.lbTitle.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbTitle.ForeColor = System.Drawing.Color.White;
			this.lbTitle.GradientEnable = true;
			this.lbTitle.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
			this.lbTitle.GradientRepeatBG = false;
			this.lbTitle.isButton = false;
			this.lbTitle.Location = new System.Drawing.Point(6, 5);
			this.lbTitle.MouseDownColor = System.Drawing.Color.Yellow;
			this.lbTitle.MouseOverColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.lbTitle.msg = null;
			this.lbTitle.Name = "lbTitle";
			this.lbTitle.ProgressBorderColor = System.Drawing.Color.Black;
			this.lbTitle.ProgressColor1 = System.Drawing.Color.LightSkyBlue;
			this.lbTitle.ProgressColor2 = System.Drawing.Color.DeepSkyBlue;
			this.lbTitle.ProgressEnable = false;
			this.lbTitle.ProgressFont = new System.Drawing.Font("Consolas", 10F);
			this.lbTitle.ProgressForeColor = System.Drawing.Color.Black;
			this.lbTitle.ProgressMax = 100F;
			this.lbTitle.ProgressMin = 0F;
			this.lbTitle.ProgressPadding = new System.Windows.Forms.Padding(0);
			this.lbTitle.ProgressValue = 0F;
			this.lbTitle.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
			this.lbTitle.Sign = "";
			this.lbTitle.SignAlign = System.Drawing.ContentAlignment.BottomRight;
			this.lbTitle.SignColor = System.Drawing.Color.Yellow;
			this.lbTitle.SignFont = new System.Drawing.Font("Consolas", 7F, System.Drawing.FontStyle.Italic);
			this.lbTitle.Size = new System.Drawing.Size(1088, 44);
			this.lbTitle.TabIndex = 2;
			this.lbTitle.Text = "INPUT";
			this.lbTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lbTitle.TextShadow = true;
			this.lbTitle.TextVisible = true;
			// 
			// button1
			// 
			this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.button1.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button1.Location = new System.Drawing.Point(1028, 11);
			this.button1.Margin = new System.Windows.Forms.Padding(0);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(60, 34);
			this.button1.TabIndex = 3;
			this.button1.Text = "닫기";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.tbInput);
			this.panel1.Controls.Add(this.button3);
			this.panel1.Controls.Add(this.button2);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(6, 49);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(1088, 47);
			this.panel1.TabIndex = 4;
			// 
			// button3
			// 
			this.button3.Dock = System.Windows.Forms.DockStyle.Right;
			this.button3.Location = new System.Drawing.Point(988, 0);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(100, 47);
			this.button3.TabIndex = 1;
			this.button3.Text = "1문자 삭제";
			this.button3.UseVisualStyleBackColor = true;
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// button2
			// 
			this.button2.Dock = System.Windows.Forms.DockStyle.Left;
			this.button2.Location = new System.Drawing.Point(0, 0);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(100, 47);
			this.button2.TabIndex = 0;
			this.button2.Text = "1문자 삭제";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// fTouchKeyFull
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
			this.ClientSize = new System.Drawing.Size(1100, 460);
			this.Controls.Add(this.touchKeyFull1);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.lbTitle);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.KeyPreview = true;
			this.Name = "fTouchKeyFull";
			this.Padding = new System.Windows.Forms.Padding(6, 5, 6, 5);
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "fTouchKeyFull";
			this.Load += new System.EventHandler(this.fTouchKeyFull_Load);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.ResumeLayout(false);

        }

        #endregion

        private arCtl.TouchKeyFull touchKeyFull1;
        private arCtl.arLabel lbTitle;
        public System.Windows.Forms.TextBox tbInput;
        private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button2;
	}
}