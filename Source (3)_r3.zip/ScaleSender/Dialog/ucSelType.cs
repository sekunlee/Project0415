﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project.Dialog
{
    public partial class ucSelType : UserControl
    {
        public int type = 1;
        public ucSelType()
        {
            InitializeComponent();
        }

        private void ucSelType_Load(object sender, EventArgs e)
        {
            tmDisplay.Start();
        }

        private void tmDisplay_Tick(object sender, EventArgs e)
        {
            if(type == 1)
            {
                btAdhesive.BackColor = Color.FromArgb(228, 85, 83);
                btAdhesive.ForeColor = Color.WhiteSmoke;

                btGrease.BackColor = Color.FromArgb(171, 171, 171);
                btGrease.ForeColor = Color.Black;
            }else if(type == 2)
            {
                btAdhesive.BackColor = Color.FromArgb(171, 171, 171);
                btAdhesive.ForeColor = Color.Black;

                btGrease.BackColor = Color.FromArgb(228, 85, 83);
                btGrease.ForeColor = Color.WhiteSmoke;
            }
            else
            {
                btAdhesive.BackColor = Color.FromArgb(171, 171, 171);
                btAdhesive.ForeColor = Color.Black;

                btGrease.BackColor = Color.FromArgb(171, 171, 171);
                btGrease.ForeColor = Color.Black;
            }
        }

        private void btAdhesive_Click(object sender, EventArgs e)
        {
            type = 1;
        }

        private void btGrease_Click(object sender, EventArgs e)
        {
            type = 2;
        }
    }
}
