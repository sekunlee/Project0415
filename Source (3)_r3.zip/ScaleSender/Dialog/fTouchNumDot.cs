﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project.Dialog
{
    public partial class fTouchNumDot : Form
    {
        public fTouchNumDot(string value)
        {
            InitializeComponent();
            this.tbInput.KeyDown += (s1, e1) => { if (e1.KeyCode == Keys.Enter) Confirm(); };
            this.KeyPreview = true;
            this.tbInput.Text = value;
            this.KeyDown += (s1, e1) =>
            {
                if (e1.KeyCode == Keys.Escape) this.Close();
            };
        }

        private void fTouchNumDot_Load(object sender, EventArgs e)
        {
            this.tbInput.SelectAll();
            this.tbInput.Focus();
        }
        private void Confirm()
        {
            string id = tbInput.Text.Trim();
            if (id.isEmpty())
            {
                tbInput.Focus();
                return;
            }
            DialogResult = DialogResult.OK;
        }


        public void ProcessKey(ref TextBox cmb_rfid, string key)
        {
            if (key == "B")
            {
                if (cmb_rfid.Text != "")
                    cmb_rfid.Text = cmb_rfid.Text.Substring(0, cmb_rfid.Text.Length - 1);
            }
            else if (key == "C")
            {
                cmb_rfid.Text = "";
            }
            else if (key == "E")
            {
                Confirm();
            }
            else
            {
                if (cmb_rfid.SelectionLength > 0 && cmb_rfid.TextLength == cmb_rfid.SelectionLength)
                {
                    cmb_rfid.Text = key;
                }
                else if (cmb_rfid.SelectionLength > 0)
                {
                    //선택된 영역을 대체해준다.
                    cmb_rfid.SelectedText = key;
                }
                else cmb_rfid.Text += key;
            }

            cmb_rfid.SelectionLength = 0;
            if (cmb_rfid.Text != "")
                cmb_rfid.SelectionStart = cmb_rfid.Text.Length;

        }

        private void arLabel1_Click(object sender, EventArgs e)
        {
            var ctl = sender as arCtl.arLabel;
            ProcessKey(ref tbInput, ctl.Tag.ToString());
        }

    }
}
