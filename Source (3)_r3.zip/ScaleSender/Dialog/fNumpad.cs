﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project.Dialog
{
    public enum NumPadMode
    {
        BADGE, NUMBER
    }
    public partial class Numpad : Form
    {
        NumPadMode mode;
        public Numpad(string _title = "", NumPadMode _mode = NumPadMode.BADGE)
        {
            InitializeComponent();
            if (_title != "")
                label1.Text = _title;

            mode = _mode;
            if (mode == NumPadMode.BADGE)
            {
                //button10.Visible = false;
                //button11.Visible = false;

                button_Y.Location = new Point(button_Y.Location.X, 525);
                button_N.Location = new Point(button_N.Location.X, 525);

                this.Size = new Size(this.Size.Width, 623);
            }
            else if (mode == NumPadMode.NUMBER)
            {
                //button10.Visible = false;
                //button11.Visible = false;

                button_Y.Location = new Point(button_Y.Location.X, 525);
                button_N.Location = new Point(button_N.Location.X, 525);

                this.Size = new Size(this.Size.Width, 623);
            }
            else
            {
                //button10.Visible = true;
                //button11.Visible = true;
            }
        }

        private void Numpad_Load(object sender, EventArgs e)
        {
            //Pub.numpadData = "";
        }


        private void button_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;

            switch (btn.Name)
            {
                case "button0":
                    //if (textBox1.Text != "" && Convert.ToInt32(textBox1.Text) > 0)
                        textBox1.Text = textBox1.Text + "0";
                    break;
                case "button1":
                    textBox1.Text = textBox1.Text + "1";
                    break;
                case "button2":
                    textBox1.Text = textBox1.Text + "2";
                    break;
                case "button3":
                    textBox1.Text = textBox1.Text + "3";
                    break;
                case "button4":
                    textBox1.Text = textBox1.Text + "4";
                    break;
                case "button5":
                    textBox1.Text = textBox1.Text + "5";
                    break;
                case "button6":
                    textBox1.Text = textBox1.Text + "6";
                    break;
                case "button7":
                    textBox1.Text = textBox1.Text + "7";
                    break;
                case "button8":
                    textBox1.Text = textBox1.Text + "8";
                    break;
                case "button9":
                    textBox1.Text = textBox1.Text + "9";
                    break;
                case "button_pad_del":
                    if (textBox1.Text.Length > 0)
                        textBox1.Text = textBox1.Text.Substring(0, textBox1.Text.Length - 1);
                    break;
                case "button10":
                    textBox1.Text = textBox1.Text + ".";
                    break;
                case "button11":
                    if (textBox1.Text == "")
                        textBox1.Text = "-" + textBox1.Text;
                    else if (textBox1.Text.First() == '-')
                        textBox1.Text = textBox1.Text.Replace("-", "");
                    else
                        textBox1.Text = "-" + textBox1.Text;
                    break;
            }
        }

        private void button_Y_Click(object sender, EventArgs e)
        {
            Pub.lockPwInputData = textBox1.Text;
            DialogResult = DialogResult.OK;
            //Close();
        }

        private void button_N_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            //Close();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button_Y_Click(null, null);
            }
        }
    }
}
