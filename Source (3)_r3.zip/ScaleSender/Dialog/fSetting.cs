﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Project.Dialog
{
    public partial class fSetting : Form
    {
        public fSetting()
        {
            InitializeComponent();
        }

        private void fSetting_Load(object sender, EventArgs e)
        {
            propertyGrid1.SelectedObject = Pub.setting;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Pub.setting.Save();
            this.Close();
            
//            UpdateFile("setting.inf", 0, $"1.MEASUREMENTASSETNO:{Pub.setting.MeasurementAssetNo}");
            UpdateFile("setting.inf", 2, $"3.LINECODE:{Pub.setting.lineCode.Replace(',', '&')}: // IF Multi Line Code, LineCode&LineCode");
            UpdateFile("setting.inf", 32, $"33.MAIL:{Pub.setting.email}: // MAIL ADDRESS, EMPTY : DISABLE");

            this.DialogResult = DialogResult.OK;
        }

        public static void UpdateFile(string fileFullPath, int pos, string data)
        {
            var lines = File.ReadAllLines(fileFullPath);
            if (pos < 0) return;
            lines[pos] = data; 
            File.WriteAllLines(fileFullPath, lines);
        }

    }
}
