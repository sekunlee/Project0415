﻿
namespace Project
{
    partial class fMain
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fMain));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btSetting = new System.Windows.Forms.ToolStripButton();
            this.btLog = new System.Windows.Forms.ToolStripButton();
            this.tmDisplay = new System.Windows.Forms.Timer(this.components);
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.backgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            this.backgroundWorker3 = new System.ComponentModel.BackgroundWorker();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.sbSerialState1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.sbState = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.lbLotNo = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.sbStateMsg = new System.Windows.Forms.ToolStripStatusLabel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.btSend = new System.Windows.Forms.Button();
            this.btSMInput = new System.Windows.Forms.Button();
            this.btClear = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btSetting,
            this.btLog});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1166, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btSetting
            // 
            this.btSetting.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btSetting.Image = ((System.Drawing.Image)(resources.GetObject("btSetting.Image")));
            this.btSetting.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btSetting.Name = "btSetting";
            this.btSetting.Size = new System.Drawing.Size(97, 22);
            this.btSetting.Text = "Setting (F11)";
            this.btSetting.Click += new System.EventHandler(this.btSetting_Click);
            // 
            // btLog
            // 
            this.btLog.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btLog.Image = ((System.Drawing.Image)(resources.GetObject("btLog.Image")));
            this.btLog.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btLog.Name = "btLog";
            this.btLog.Size = new System.Drawing.Size(47, 22);
            this.btLog.Text = "Log";
            this.btLog.Click += new System.EventHandler(this.btLog_Click);
            // 
            // tmDisplay
            // 
            this.tmDisplay.Interval = 250;
            this.tmDisplay.Tick += new System.EventHandler(this.tmDisplay_Tick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sbSerialState1,
            this.toolStripStatusLabel1,
            this.sbState,
            this.toolStripStatusLabel4,
            this.lbLotNo,
            this.toolStripStatusLabel2,
            this.sbStateMsg});
            this.statusStrip1.Location = new System.Drawing.Point(0, 704);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1166, 24);
            this.statusStrip1.TabIndex = 61;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // sbSerialState1
            // 
            this.sbSerialState1.Font = new System.Drawing.Font("맑은 고딕", 10F, System.Drawing.FontStyle.Bold);
            this.sbSerialState1.Name = "sbSerialState1";
            this.sbSerialState1.Size = new System.Drawing.Size(73, 19);
            this.sbSerialState1.Text = "{SERIAL1}";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(10, 19);
            this.toolStripStatusLabel1.Text = "|";
            // 
            // sbState
            // 
            this.sbState.Font = new System.Drawing.Font("맑은 고딕", 10F, System.Drawing.FontStyle.Bold);
            this.sbState.Name = "sbState";
            this.sbState.Size = new System.Drawing.Size(61, 19);
            this.sbState.Text = "{STATE}";
            // 
            // toolStripStatusLabel4
            // 
            this.toolStripStatusLabel4.Name = "toolStripStatusLabel4";
            this.toolStripStatusLabel4.Size = new System.Drawing.Size(10, 19);
            this.toolStripStatusLabel4.Text = "|";
            // 
            // lbLotNo
            // 
            this.lbLotNo.Font = new System.Drawing.Font("맑은 고딕", 10F, System.Drawing.FontStyle.Bold);
            this.lbLotNo.Name = "lbLotNo";
            this.lbLotNo.Size = new System.Drawing.Size(78, 19);
            this.lbLotNo.Text = "{LOT 정보}";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(10, 19);
            this.toolStripStatusLabel2.Text = "|";
            // 
            // sbStateMsg
            // 
            this.sbStateMsg.Font = new System.Drawing.Font("맑은 고딕", 10F, System.Drawing.FontStyle.Bold);
            this.sbStateMsg.Name = "sbStateMsg";
            this.sbStateMsg.Size = new System.Drawing.Size(51, 19);
            this.sbStateMsg.Text = "{MSG}";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.Controls.Add(this.btSend, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.btSMInput, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.btClear, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 604);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1166, 100);
            this.tableLayoutPanel2.TabIndex = 62;
            // 
            // btSend
            // 
            this.btSend.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(29)))), ((int)(((byte)(119)))));
            this.btSend.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btSend.Font = new System.Drawing.Font("맑은 고딕", 25F);
            this.btSend.ForeColor = System.Drawing.Color.White;
            this.btSend.Location = new System.Drawing.Point(776, 10);
            this.btSend.Margin = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btSend.Name = "btSend";
            this.btSend.Size = new System.Drawing.Size(390, 90);
            this.btSend.TabIndex = 19;
            this.btSend.Text = "SPC 전송";
            this.btSend.UseVisualStyleBackColor = false;
            this.btSend.Click += new System.EventHandler(this.btSend_Click);
            // 
            // btSMInput
            // 
            this.btSMInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(29)))), ((int)(((byte)(119)))));
            this.btSMInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btSMInput.Font = new System.Drawing.Font("맑은 고딕", 25F);
            this.btSMInput.ForeColor = System.Drawing.Color.White;
            this.btSMInput.Location = new System.Drawing.Point(388, 10);
            this.btSMInput.Margin = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btSMInput.Name = "btSMInput";
            this.btSMInput.Size = new System.Drawing.Size(388, 90);
            this.btSMInput.TabIndex = 18;
            this.btSMInput.Text = "SM 입력";
            this.btSMInput.UseVisualStyleBackColor = false;
            this.btSMInput.Click += new System.EventHandler(this.button1_Click);
            // 
            // btClear
            // 
            this.btClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(40)))), ((int)(((byte)(79)))));
            this.btClear.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btClear.Font = new System.Drawing.Font("맑은 고딕", 25F);
            this.btClear.ForeColor = System.Drawing.Color.White;
            this.btClear.Location = new System.Drawing.Point(0, 10);
            this.btClear.Margin = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btClear.Name = "btClear";
            this.btClear.Size = new System.Drawing.Size(388, 90);
            this.btClear.TabIndex = 16;
            this.btClear.Text = "초기화";
            this.btClear.UseVisualStyleBackColor = false;
            this.btClear.Click += new System.EventHandler(this.btClear_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34F));
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 25);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(10, 20, 10, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1166, 579);
            this.tableLayoutPanel1.TabIndex = 19;
            // 
            // fMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1166, 728);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "fMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this._Close);
            this.Load += new System.EventHandler(this._Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btSetting;
        private System.Windows.Forms.ToolStripButton btLog;
        private System.Windows.Forms.Timer tmDisplay;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.ComponentModel.BackgroundWorker backgroundWorker2;
        private System.ComponentModel.BackgroundWorker backgroundWorker3;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button btClear;
        private System.Windows.Forms.ToolStripStatusLabel sbState;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ToolStripStatusLabel sbStateMsg;
        private System.Windows.Forms.ToolStripStatusLabel sbSerialState1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.Button btSMInput;
        private System.Windows.Forms.Button btSend;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel4;
        private System.Windows.Forms.ToolStripStatusLabel lbLotNo;
    }
}

