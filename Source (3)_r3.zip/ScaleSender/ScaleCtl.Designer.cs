﻿namespace Project
{
    partial class ScaleCtl
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbTitle = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.val = new System.Windows.Forms.Label();
            this.lbSign = new System.Windows.Forms.Label();
            this.lbUnit = new System.Windows.Forms.Label();
            this.btGet = new System.Windows.Forms.Button();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbTitle
            // 
            this.lbTitle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(29)))), ((int)(((byte)(59)))));
            this.lbTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbTitle.Font = new System.Drawing.Font("맑은 고딕", 25F);
            this.lbTitle.ForeColor = System.Drawing.Color.White;
            this.lbTitle.Location = new System.Drawing.Point(0, 0);
            this.lbTitle.Name = "lbTitle";
            this.lbTitle.Size = new System.Drawing.Size(282, 50);
            this.lbTitle.TabIndex = 2;
            this.lbTitle.Text = "Value";
            this.lbTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(80)))), ((int)(((byte)(160)))));
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.val);
            this.panel7.Controls.Add(this.lbSign);
            this.panel7.Controls.Add(this.lbUnit);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 50);
            this.panel7.Margin = new System.Windows.Forms.Padding(0, 0, 20, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(282, 125);
            this.panel7.TabIndex = 51;
            // 
            // val
            // 
            this.val.Dock = System.Windows.Forms.DockStyle.Fill;
            this.val.Font = new System.Drawing.Font("굴림", 40F, System.Drawing.FontStyle.Bold);
            this.val.ForeColor = System.Drawing.Color.White;
            this.val.Location = new System.Drawing.Point(48, 0);
            this.val.Name = "val";
            this.val.Size = new System.Drawing.Size(154, 123);
            this.val.TabIndex = 2;
            this.val.Text = "0";
            this.val.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbSign
            // 
            this.lbSign.Dock = System.Windows.Forms.DockStyle.Left;
            this.lbSign.Font = new System.Drawing.Font("굴림", 50F, System.Drawing.FontStyle.Bold);
            this.lbSign.ForeColor = System.Drawing.Color.White;
            this.lbSign.Location = new System.Drawing.Point(0, 0);
            this.lbSign.Name = "lbSign";
            this.lbSign.Size = new System.Drawing.Size(48, 123);
            this.lbSign.TabIndex = 7;
            this.lbSign.Text = "+";
            this.lbSign.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbSign.Visible = false;
            // 
            // lbUnit
            // 
            this.lbUnit.Dock = System.Windows.Forms.DockStyle.Right;
            this.lbUnit.Font = new System.Drawing.Font("굴림", 30F, System.Drawing.FontStyle.Bold);
            this.lbUnit.ForeColor = System.Drawing.Color.White;
            this.lbUnit.Location = new System.Drawing.Point(152, 0);
            this.lbUnit.Name = "lbUnit";
            this.lbUnit.Size = new System.Drawing.Size(150, 123);
            this.lbUnit.TabIndex = 6;
            this.lbUnit.Text = "g";
            this.lbUnit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btGet
            // 
            this.btGet.AutoSize = true;
            this.btGet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(80)))), ((int)(((byte)(160)))));
            this.btGet.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btGet.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btGet.FlatAppearance.BorderSize = 0;
            this.btGet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btGet.Font = new System.Drawing.Font("맑은 고딕", 25F);
            this.btGet.ForeColor = System.Drawing.Color.White;
            this.btGet.Location = new System.Drawing.Point(0, 175);
            this.btGet.Name = "btGet";
            this.btGet.Size = new System.Drawing.Size(282, 56);
            this.btGet.TabIndex = 54;
            this.btGet.Text = "GET DATA";
            this.btGet.UseVisualStyleBackColor = false;
            // 
            // ScaleCtl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.lbTitle);
            this.Controls.Add(this.btGet);
            this.Name = "ScaleCtl";
            this.Size = new System.Drawing.Size(282, 231);
            this.panel7.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel7;
        public System.Windows.Forms.Label lbSign;
        private System.Windows.Forms.Label lbUnit;
        public System.Windows.Forms.Button btGet;
        public System.Windows.Forms.Label val;
        public System.Windows.Forms.Label lbTitle;
    }
}
