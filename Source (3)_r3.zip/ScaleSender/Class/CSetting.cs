﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace Project.Class
{
    public class CSetting : arUtil.Setting
    {
        [Category("저울"), DisplayName("모델"), Description("")]
        public string scaleDevice { get; set; }
        [Category("저울"), DisplayName("모델"), Description("")]
        public eScaleModel scaleModel { get; set; }
        [Category("저울"), DisplayName("단위"), Description("")]
        public string scaleUnit { get; set; }
        //[Category("저울"), DisplayName("데이터 개수"), Description("")]
        //public int scaleDataCnt { get; set; }

        [Category("저울 통신설정"), DisplayName("COM PORT"), Description("")]
        public string Port { get; set; }
        [Category("저울 통신설정"), DisplayName("Baud Rate"), Description("")]
        public int baud { get; set; }
        [Category("저울 통신설정"), DisplayName("Data Bit"), Description("")]
        public int dataBit { get; set; }


        [Category("바코드 통신설정"), DisplayName("COM PORT"), Description("")]
        public string bcPort { get; set; }
        [Category("바코드 통신설정"), DisplayName("Baud Rate"), Description("")]
        public int bcBaud { get; set; }
        [Category("바코드 통신설정"), DisplayName("Data Bit"), Description("")]
        public int bcDataBit { get; set; }
        /*
                [Category("Parameter"), DisplayName("MeasurementAssetNo"), Description("Equipment Mesasurement Asset No.")]
                public string MeasurementAssetNo { get; set; }
                */

        [Category("Parameter"), DisplayName("Line code"), Description("")]
        public string lineCode { get; set; }
        [Category("Parameter"), DisplayName("Rsc Desc"), Description("")]
        public string rscDesc { get; set; }
        [Category("Parameter"), DisplayName("Email"), Description("MAIL ADDRESS, EMPTY : DISABLE")]
        public string email { get; set; }

        public override void AfterLoad()
        {
            if (baud == 0) baud = 2400;
            if (bcBaud == 0) bcBaud = 9600;
            if (dataBit == 0) dataBit = 7;
            if (bcDataBit == 0) bcDataBit = 7;

            if (Port.isEmpty() == true)
            {
                Port = "COM11";
            }

            if(bcPort.isEmpty() == true)
            {
                bcPort = "COM12";
            }

            if(lineCode.isEmpty() == true)
            {
                lineCode = "";
            }

            if(scaleUnit.isEmpty() == true)
            {
                scaleUnit = "g";
            }

            if (string.IsNullOrEmpty(scaleDevice))
            {
                scaleDevice = "Scale01";
            }

            var sm = Xml.get_Data("user", "sModel");
            if (string.IsNullOrEmpty(sm)) sm = "0";
            scaleModel = (eScaleModel)int.Parse(sm);

            //if (string.IsNullOrEmpty(scaleModel.ToString())) scaleModel = 1;
            //throw new NotImplementedException();
        }

        public override void AfterSave()
        {
            //throw new NotImplementedException();
            Xml.set_Data("user", "sModel", ((int)scaleModel).ToString());
            Xml.Save(out string message);
        }
    }
}
