﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Project.Class
{
    public class Header
    {
        public string linecode { get; set; }
        public string productionAsset { get; set; }
        public string measurementAsset { get; set; }
        public string carrierId { get; set; }
        public string amkorId { get; set; }
        public string subId { get; set; }
        public string dataGroup { get; set; }
        public string operation { get; set; }
        public string slotNo { get; set; }
        public string measurementItem { get; set; }
        public string lotId { get; set; }
        public string dcc { get; set; }
        public string sm { get; set; }
        public string pdl { get; set; }
        public string custCode { get; set; }
        public string targetDevice { get; set; }

        public Header()
        {
        }
        public Header(string strData)
        {
            int i = 0;
            var spList = strData.Substring(1, strData.Length - 2).Split('^');
            linecode = spList[i++];
            productionAsset = spList[i++];
            measurementAsset = spList[i++];
            carrierId = spList[i++];
            amkorId = spList[i++];
            subId = spList[i++];
            dataGroup = spList[i++];
            operation = spList[i++];
            slotNo = spList[i++];
            measurementItem = spList[i++];
            lotId = spList[i++];
            dcc = spList[i++];
            sm = spList[i++];
            pdl = spList[i++];
            custCode = spList[i++];
            targetDevice = spList[i++];
        }




    }



    public class MeasurementRecord
    {
        public Header header { get; set; }
        public string slotNo { get; set; }
        public string measurementItem { get; set; }
        public DateTime date { get; set; }
        public string unit { get; set; }
        public List<float> valList { get; set; }
        public string type { get; set; }



        public MeasurementRecord()
        { }
        public MeasurementRecord(Header he, string _measurementItem, string _unit, List<float> _valList)
        {
            header = he;
            date = DateTime.Now;

            measurementItem = _measurementItem;
            unit = _unit;
            valList = _valList;
            slotNo = "0";
        }



        public override string ToString()
        {

            string strvalues = string.Empty;
            int i = 0;
            foreach (var r in valList)
            {
                string str = string.Format("^^^^^^^^^Value_{0}^{1}^", (i++) + 1, r.ToString());
                strvalues += str;
            }
            string packet = string.Format("[{0}^{1}^{2}^{3}^{4}^{5}^{6}^{7}^{8}^{9}^{10}^{11}^{12}]", header.linecode, header.productionAsset, header.measurementAsset, header.carrierId, header.amkorId, header.subId, header.dataGroup, header.operation, header.slotNo, measurementItem, date.ToString("yyyyMMddHHmmss"), unit, strvalues);

            return packet;
        }
    }
}