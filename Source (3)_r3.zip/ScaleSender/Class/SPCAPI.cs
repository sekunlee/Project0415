﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace Project.Class
{
    public static class SPCAPI
    {
        
        [DllImport("Measurement.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
        public static extern string Send_MeasurementResult(string inData);
        [DllImport("Measurement.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
        public static extern string Send_LotListResult(string inData);
        [DllImport("Measurement.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
        public static extern string Send_ProductionResult(string inData);
        
    }
}
